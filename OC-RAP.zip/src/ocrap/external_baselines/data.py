from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import Dataset

from ocrap.data.serialization import load_npz
from ocrap.models.data import iter_sample_paths_many, sample_to_feature, scalar_metadata_for_path


# The external-baseline adapters intentionally derive all supervision from the
# current OC-RAP sample files.  No OC-RAP model predictions or calibration labels
# are used as inputs to GameFormer/BeTop policies.
ACTOR_TOPO_FEATURE_DIM = 16
MAP_TOPO_FEATURE_DIM = 14
GAMEFORMER_STATE_DIM = 9


def _scalar(d: dict[str, Any], key: str, default: float = 0.0) -> float:
    try:
        return float(np.asarray(d.get(key, default)).item())
    except Exception:
        return float(default)


def _int(d: dict[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(np.asarray(d.get(key, default)).item())
    except Exception:
        return int(default)


def _str(d: dict[str, Any], key: str, default: str = "") -> str:
    try:
        v = np.asarray(d.get(key, default)).item()
        if isinstance(v, bytes):
            return v.decode("utf-8", errors="ignore")
        return str(v)
    except Exception:
        return str(default)


def _cfg_int(cfg: dict[str, Any], path: tuple[str, ...], default: int) -> int:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return int(default)
        cur = cur[key]
    try:
        return int(cur)
    except Exception:
        return int(default)


def _cfg_float(cfg: dict[str, Any], path: tuple[str, ...], default: float) -> float:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return float(default)
        cur = cur[key]
    try:
        return float(cur)
    except Exception:
        return float(default)


def _pad_1d(x: Any, n: int, *, fill: float = 0.0, dtype=np.float32) -> np.ndarray:
    out = np.full((int(n),), fill, dtype=dtype)
    if n <= 0:
        return out
    v = np.asarray(x, dtype=dtype).reshape(-1)
    m = min(int(n), int(v.size))
    if m > 0:
        out[:m] = v[:m]
    return np.nan_to_num(out, nan=fill, posinf=fill, neginf=fill)


def _pad_bool_1d(x: Any, n: int, *, fill: bool = False) -> np.ndarray:
    out = np.full((int(n),), bool(fill), dtype=bool)
    if n <= 0:
        return out
    v = np.asarray(x).reshape(-1).astype(bool)
    m = min(int(n), int(v.size))
    if m > 0:
        out[:m] = v[:m]
    return out


def _pad_2d(x: Any, shape: tuple[int, int], *, fill: float = 0.0, dtype=np.float32) -> np.ndarray:
    r, c = int(shape[0]), int(shape[1])
    out = np.full((r, c), fill, dtype=dtype)
    if r <= 0 or c <= 0:
        return out
    v = np.asarray(x, dtype=dtype)
    if v.ndim == 1:
        v = v.reshape(1, -1)
    if v.ndim != 2:
        return out
    rr, cc = min(r, v.shape[0]), min(c, v.shape[1])
    if rr > 0 and cc > 0:
        out[:rr, :cc] = v[:rr, :cc]
    return np.nan_to_num(out, nan=fill, posinf=fill, neginf=fill)


def _pad_3d(x: Any, shape: tuple[int, int, int], *, fill: float = 0.0, dtype=np.float32) -> np.ndarray:
    a, b, c = int(shape[0]), int(shape[1]), int(shape[2])
    out = np.full((a, b, c), fill, dtype=dtype)
    if a <= 0 or b <= 0 or c <= 0:
        return out
    v = np.asarray(x, dtype=dtype)
    if v.ndim != 3:
        return out
    aa, bb, cc = min(a, v.shape[0]), min(b, v.shape[1]), min(c, v.shape[2])
    if aa > 0 and bb > 0 and cc > 0:
        out[:aa, :bb, :cc] = v[:aa, :bb, :cc]
    return np.nan_to_num(out, nan=fill, posinf=fill, neginf=fill)


def _branch_arrays(d: dict[str, Any], cfg: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return fixed branch tensors used by GameFormer-level-k training."""
    m_raw = np.asarray(d.get("m_star", np.zeros((1, 0))), dtype=np.float32)
    K_default = int(m_raw.shape[0]) if m_raw.ndim >= 1 and m_raw.shape[0] else int(cfg.get("num_roots", 10))
    L_default = int(m_raw.shape[1]) if m_raw.ndim >= 2 and m_raw.shape[1] else int(cfg.get("num_recovery_options", 12))
    K = _cfg_int(cfg, ("external_baselines", "model", "num_roots"), _cfg_int(cfg, ("num_roots",), K_default))
    L = _cfg_int(cfg, ("external_baselines", "model", "num_options"), _cfg_int(cfg, ("num_recovery_options",), L_default))
    F = _cfg_int(cfg, ("external_baselines", "model", "root_feature_dim"), 18)
    m = _pad_2d(d.get("m_star", np.zeros((0, 0))), (K, L), fill=-1.0, dtype=np.float32)
    root_probs = _pad_1d(d.get("root_probs", np.ones((K,), dtype=np.float32) / max(K, 1)), K, fill=0.0, dtype=np.float32)
    root_valid = _pad_bool_1d(d.get("root_valid", root_probs > 0), K, fill=False)
    root_probs = np.where(root_valid, np.clip(root_probs, 0.0, None), 0.0).astype(np.float32)
    den = float(root_probs.sum())
    if den > 1e-8:
        root_probs /= den
    sig = np.asarray(d.get("root_signature", np.zeros((K, 0))), dtype=np.float32)
    fsig = np.asarray(d.get("root_future_signature", np.zeros((K, 0))), dtype=np.float32)
    if sig.ndim != 2:
        sig = np.zeros((K, 0), dtype=np.float32)
    if fsig.ndim != 2:
        fsig = np.zeros((K, 0), dtype=np.float32)
    sig = _pad_2d(sig, (K, sig.shape[-1] if sig.ndim == 2 else 0), fill=0.0)
    fsig = _pad_2d(fsig, (K, fsig.shape[-1] if fsig.ndim == 2 else 0), fill=0.0)
    raw_feat = np.concatenate([sig, fsig, root_probs[:, None].astype(np.float32), root_valid[:, None].astype(np.float32)], axis=-1)
    root_features = _pad_2d(raw_feat, (K, F), fill=0.0, dtype=np.float32)
    option_valid = _pad_bool_1d(d.get("option_valid", np.ones((L,), dtype=bool)), L, fill=False)
    return m, root_features, root_probs.astype(np.float32), root_valid.astype(bool), option_valid.astype(bool)


def _split_matches_path(path: Path, split: str | set[str]) -> bool:
    splits = {split} if isinstance(split, str) else set(split)
    if "all" in {str(x).lower() for x in splits}:
        return True
    sid = str(scalar_metadata_for_path(path, "split_id", ""))
    return sid in splits


def dataset_label_for_path(path: Path) -> str:
    root = path.parent.parent if path.parent.name == "samples" else path.parent
    return root.name


def group_sample_paths(dataset: str | Path, split: str | set[str] = "train") -> list[list[Path]]:
    paths = iter_sample_paths_many(dataset)
    grouped: dict[tuple[str, str, int], list[Path]] = defaultdict(list)
    for p in paths:
        p = Path(p)
        if not _split_matches_path(p, split):
            continue
        d = load_npz(p)
        scene_id = _str(d, "scene_id", "")
        time_index = _int(d, "time_index", 0)
        grouped[(dataset_label_for_path(p), scene_id, time_index)].append(p)
    out: list[list[Path]] = []
    for _, group in sorted(grouped.items(), key=lambda kv: (kv[0][0], kv[0][1], kv[0][2])):
        group = sorted(group, key=lambda p: _int(load_npz(p), "candidate_index", 0))
        out.append(group)
    return out


def _last_valid_agent_states(agent_history: Any, agent_valid: Any) -> tuple[np.ndarray, np.ndarray]:
    hist = np.asarray(agent_history, dtype=np.float32)
    valid = np.asarray(agent_valid).astype(bool)
    if hist.ndim != 3 or valid.ndim != 2 or hist.shape[:2] != valid.shape:
        return np.zeros((0, 16), dtype=np.float32), np.zeros((0,), dtype=bool)
    _, A, F = hist.shape
    out = np.zeros((A, F), dtype=np.float32)
    out_valid = np.zeros((A,), dtype=bool)
    for a in range(A):
        idx = np.where(valid[:, a])[0]
        if idx.size:
            out[a] = hist[int(idx[-1]), a]
            out_valid[a] = True
    return out, out_valid


def _ego_prefix_xy(d: dict[str, Any]) -> np.ndarray:
    states = np.asarray(d.get("prefix_states", np.zeros((0, 0))), dtype=np.float32)
    if states.ndim == 2 and states.shape[0] > 0 and states.shape[1] >= 2:
        xy = states[:, :2].astype(np.float32)
        if np.isfinite(xy).all():
            return xy
    ego = np.asarray(d.get("ego_state", np.zeros((9,))), dtype=np.float32).reshape(-1)
    x = float(ego[0]) if ego.size > 0 else 0.0
    y = float(ego[1]) if ego.size > 1 else 0.0
    return np.asarray([[x, y], [x, y]], dtype=np.float32)


def _resample_xy(xy: np.ndarray, T: int) -> tuple[np.ndarray, np.ndarray]:
    out = np.zeros((T, 2), dtype=np.float32)
    valid = np.zeros((T,), dtype=bool)
    xy = np.asarray(xy, dtype=np.float32)
    if xy.ndim != 2 or xy.shape[0] == 0 or xy.shape[1] < 2:
        return out, valid
    if xy.shape[0] == T:
        out[:] = xy[:, :2]
        valid[:] = True
        return np.nan_to_num(out), valid
    src = np.linspace(0.0, 1.0, xy.shape[0], dtype=np.float32)
    dst = np.linspace(0.0, 1.0, T, dtype=np.float32)
    out[:, 0] = np.interp(dst, src, xy[:, 0])
    out[:, 1] = np.interp(dst, src, xy[:, 1])
    valid[:] = True
    return np.nan_to_num(out), valid


def _history_arrays(d: dict[str, Any], cfg: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """GameFormer-style ego/neighbor history and candidate-prefix trajectory.

    The uploaded GameFormer source encodes ego/neighbor history with AgentEncoder
    LSTMs and decodes multi-modal future trajectories.  OC-RAP does not store the
    native GameFormer npz schema, so we expose equivalent tensors from the OC-RAP
    sample: agent_history for actor sequences and prefix_states for the ego
    candidate trajectory that acts as the imitation target.
    """
    H = _cfg_int(cfg, ("external_baselines", "model", "history_len"), 11)
    A = _cfg_int(cfg, ("external_baselines", "model", "neighbors_to_predict"), 8)
    T = _cfg_int(cfg, ("external_baselines", "model", "future_len"), 20)
    hist = np.asarray(d.get("agent_history", np.zeros((0, 0, 0))), dtype=np.float32)
    valid = np.asarray(d.get("agent_valid", np.zeros((0, 0))), dtype=bool)
    ego_state = np.asarray(d.get("ego_state", np.zeros((GAMEFORMER_STATE_DIM,))), dtype=np.float32).reshape(-1)

    ego_hist = np.zeros((H, GAMEFORMER_STATE_DIM), dtype=np.float32)
    neigh_hist = np.zeros((A, H, GAMEFORMER_STATE_DIM), dtype=np.float32)
    neigh_valid = np.zeros((A, H), dtype=bool)
    if hist.ndim == 3 and hist.shape[0] > 0:
        hsel = hist[-H:]
        vsel = valid[-H:] if valid.ndim == 2 and valid.shape[:2] == hist.shape[:2] else np.ones(hsel.shape[:2], dtype=bool)
        hpad = np.zeros((H, hist.shape[1], hist.shape[2]), dtype=np.float32)
        vpad = np.zeros((H, hist.shape[1]), dtype=bool)
        hpad[-hsel.shape[0] :] = hsel
        vpad[-vsel.shape[0] :] = vsel
        if hpad.shape[1] > 0:
            ego_raw = hpad[:, 0, :GAMEFORMER_STATE_DIM]
            ego_hist[:, : ego_raw.shape[1]] = ego_raw
        for a in range(min(A, max(hpad.shape[1] - 1, 0))):
            raw = hpad[:, a + 1, :GAMEFORMER_STATE_DIM]
            neigh_hist[a, :, : raw.shape[1]] = raw
            neigh_valid[a] = vpad[:, a + 1]
    else:
        m = min(GAMEFORMER_STATE_DIM, ego_state.size)
        ego_hist[:, :m] = ego_state[:m]

    prefix_xy, prefix_valid = _resample_xy(_ego_prefix_xy(d), T)
    return (
        np.nan_to_num(ego_hist, nan=0.0, posinf=0.0, neginf=0.0),
        np.nan_to_num(neigh_hist, nan=0.0, posinf=0.0, neginf=0.0),
        neigh_valid.astype(bool),
        prefix_xy,
        prefix_valid.astype(bool),
    )


def _crossing_binary(src_xy: np.ndarray, tgt_xy: np.ndarray, threshold: float = 3.0) -> bool:
    """Binary behavior-braid proxy following BeTop's x-time crossing idea."""
    T = min(src_xy.shape[0], tgt_xy.shape[0])
    if T < 2:
        return False
    src = src_xy[:T]
    tgt = tgt_xy[:T]
    dist = np.linalg.norm(src - tgt, axis=-1)
    if bool(np.nanmin(dist) < threshold):
        return True
    # BeTop tests intersections in a projected braid plane.  Here we use signed
    # longitudinal order change as the lightweight OC-RAP-compatible proxy.
    rel0 = tgt[0] - src[0]
    relT = tgt[-1] - src[-1]
    fwd = src[-1] - src[0]
    n = float(np.linalg.norm(fwd))
    if n < 1e-3:
        fwd = np.asarray([1.0, 0.0], dtype=np.float32)
    else:
        fwd = fwd / n
    lon0 = float(np.dot(rel0, fwd))
    lonT = float(np.dot(relT, fwd))
    lat_min = float(np.min(np.abs((tgt - src) @ np.asarray([-fwd[1], fwd[0]], dtype=np.float32))))
    return (lon0 * lonT < 0.0) and (lat_min < threshold)


def _actor_topology_arrays(d: dict[str, Any], cfg: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    Amax = _cfg_int(cfg, ("external_baselines", "model", "num_topology_agents"), _cfg_int(cfg, ("max_agents",), 16))
    Amax = max(Amax, 1)
    T = _cfg_int(cfg, ("external_baselines", "model", "future_len"), 20)
    dt = _cfg_float(cfg, ("external_baselines", "model", "topology_dt"), 0.1)
    far = _cfg_float(cfg, ("external_baselines", "model", "topology_far_threshold_m"), 30.0)
    feats = np.zeros((Amax, ACTOR_TOPO_FEATURE_DIM), dtype=np.float32)
    targets = np.zeros((Amax,), dtype=np.float32)
    mask = np.zeros((Amax,), dtype=bool)

    ego_xy, _ = _resample_xy(_ego_prefix_xy(d), T)
    e0 = ego_xy[0]
    eT = ego_xy[-1]
    ego_v = (eT - e0) / max((T - 1) * dt, 1e-3)
    fwd = eT - e0
    fwd_norm = float(np.linalg.norm(fwd))
    if fwd_norm < 1e-3:
        yaw = 0.0
        ego = np.asarray(d.get("ego_state", np.zeros((9,))), dtype=np.float32).reshape(-1)
        if ego.size >= 5:
            yaw = float(ego[4])
        elif ego.size >= 3:
            yaw = float(ego[2])
        fwd = np.asarray([np.cos(yaw), np.sin(yaw)], dtype=np.float32)
        fwd_norm = 1.0
    fwd = fwd / max(fwd_norm, 1e-6)
    left = np.asarray([-fwd[1], fwd[0]], dtype=np.float32)

    states, valid = _last_valid_agent_states(d.get("agent_history", np.zeros((0, 0, 0))), d.get("agent_valid", np.zeros((0, 0))))
    rows = []
    for a in range(1, states.shape[0]):
        if not valid[a] or states.shape[1] < 2:
            continue
        s = states[a]
        p0 = np.asarray([float(s[0]), float(s[1])], dtype=np.float32)
        v = np.asarray([float(s[3]) if s.size > 3 else 0.0, float(s[4]) if s.size > 4 else 0.0], dtype=np.float32)
        d0 = float(np.linalg.norm(p0 - e0))
        rows.append((d0, p0, v, s))
    rows.sort(key=lambda x: x[0])
    ts = np.arange(T, dtype=np.float32)[:, None] * dt
    for i, (d0, p0, v, s) in enumerate(rows[:Amax]):
        agent_xy = p0[None, :] + ts * v[None, :]
        rel0 = p0 - e0
        relT = agent_xy[-1] - eT
        dist = np.linalg.norm(agent_xy - ego_xy, axis=-1)
        min_dist = float(np.min(dist)) if dist.size else d0
        lat0 = float(np.dot(rel0, left))
        lon0 = float(np.dot(rel0, fwd))
        latT = float(np.dot(relT, left))
        lonT = float(np.dot(relT, fwd))
        closing = float(np.dot(v - ego_v, fwd))
        speed = float(np.linalg.norm(v))
        in_range = d0 <= far or min_dist <= far
        feats[i] = np.asarray([
            rel0[0] / 80.0, rel0[1] / 80.0, relT[0] / 80.0, relT[1] / 80.0,
            float(v[0]) / 20.0, float(v[1]) / 20.0, float(ego_v[0]) / 20.0, float(ego_v[1]) / 20.0,
            d0 / 80.0, min_dist / 40.0, lat0 / 20.0, lon0 / 40.0, latT / 20.0, lonT / 40.0,
            closing / 20.0, speed / 20.0,
        ], dtype=np.float32)
        targets[i] = float(in_range and _crossing_binary(ego_xy, agent_xy, threshold=3.0))
        mask[i] = bool(in_range)
    return np.nan_to_num(feats), targets.astype(np.float32), mask


def _map_topology_arrays(d: dict[str, Any], cfg: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    Mmax = _cfg_int(cfg, ("external_baselines", "model", "num_topology_map"), 64)
    Mmax = max(Mmax, 1)
    T = _cfg_int(cfg, ("external_baselines", "model", "future_len"), 20)
    ego_xy, _ = _resample_xy(_ego_prefix_xy(d), T)
    e0 = ego_xy[0]
    eT = ego_xy[-1]
    maps = np.asarray(d.get("map_polylines", np.zeros((0, 0, 0))), dtype=np.float32)
    feats = np.zeros((Mmax, MAP_TOPO_FEATURE_DIM), dtype=np.float32)
    targets = np.zeros((Mmax,), dtype=np.float32)
    mask = np.zeros((Mmax,), dtype=bool)
    if maps.ndim != 3 or maps.shape[0] == 0 or maps.shape[2] < 2:
        route = np.asarray(d.get("route", np.zeros((0, 2))), dtype=np.float32)
        if route.ndim == 2 and route.shape[0] > 1:
            maps = route[None, :, :2]
        else:
            return feats, targets, mask
    rows = []
    for m in range(maps.shape[0]):
        xy = maps[m, :, :2]
        valid = np.isfinite(xy).all(axis=-1) & (np.abs(xy).sum(axis=-1) > 1e-6)
        if int(valid.sum()) < 2:
            continue
        xy = xy[valid]
        center = xy.mean(axis=0)
        d0 = float(np.linalg.norm(center - e0))
        rows.append((d0, xy))
    rows.sort(key=lambda x: x[0])
    for i, (d0, xy) in enumerate(rows[:Mmax]):
        center = xy.mean(axis=0)
        seg = xy[-1] - xy[0]
        seg_len = float(np.linalg.norm(seg))
        seg_dir = seg / max(seg_len, 1e-6)
        # BeTop's map topology marks map polylines occupied/crossed by the future
        # trajectory.  We use min distance from candidate prefix to the polyline.
        dist = np.linalg.norm(ego_xy[:, None, :] - xy[None, :, :], axis=-1)
        min_dist = float(np.min(dist)) if dist.size else 1e6
        nearest = xy.reshape(-1, 2)[int(np.argmin(np.linalg.norm(xy - eT[None, :], axis=-1)))]
        rel0 = center - e0
        relT = nearest - eT
        feats[i] = np.asarray([
            rel0[0] / 80.0, rel0[1] / 80.0, relT[0] / 80.0, relT[1] / 80.0,
            center[0] / 200.0, center[1] / 200.0, seg_dir[0], seg_dir[1], seg_len / 80.0,
            d0 / 80.0, min_dist / 20.0, float(xy.shape[0]) / 100.0,
            float(np.std(xy[:, 0])) / 80.0, float(np.std(xy[:, 1])) / 80.0,
        ], dtype=np.float32)
        targets[i] = float(min_dist < 3.0)
        mask[i] = bool(d0 < 100.0 or min_dist < 10.0)
    return np.nan_to_num(feats), targets.astype(np.float32), mask


def _topology_arrays(d: dict[str, Any], cfg: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Backward-compatible alias for old BeTop-lite checkpoints."""
    feats, targets, mask = _actor_topology_arrays(d, cfg)
    return feats, targets.astype(np.int64), mask


def _target_index(samples: list[dict[str, Any]], baseline: str, cfg: dict[str, Any]) -> int:
    bcfg = cfg.get("external_baselines", {}) if isinstance(cfg.get("external_baselines", {}), dict) else {}
    baseline = str(baseline).lower()
    feasible = np.asarray([_scalar(d, "feasible", 1.0) > 0.5 for d in samples], dtype=bool)
    utility = np.asarray([_scalar(d, "utility", 0.0) for d in samples], dtype=np.float32)
    hard = np.asarray([_scalar(d, "hard_violation", 0.0) for d in samples], dtype=np.float32)
    harm = np.asarray([_scalar(d, "harm_proxy", 0.0) for d in samples], dtype=np.float32)
    r_orc = np.asarray([_scalar(d, "r_orc_star", 0.0) for d in samples], dtype=np.float32)
    r_dep = np.asarray([_scalar(d, "r_dep_star", 0.0) for d in samples], dtype=np.float32)

    nominal = [i for i, d in enumerate(samples) if _scalar(d, "is_nominal", 0.0) > 0.5]
    if baseline in {"nominal", "nominal_replay", "log_replay", "route_bc", "route_bc_lite", "waymax_bc", "waymax_bc_lite", "wayformer_bc", "wayformer_style_bc", "route_bc_wayformer"}:
        return int(nominal[0] if nominal else 0)

    if baseline in {"gameformer", "gameformer_lite", "gameformer_levelk"}:
        score = utility - float(bcfg.get("hard_weight", 12.0)) * hard - float(bcfg.get("harm_weight", 2.0)) * harm + float(bcfg.get("oracle_weight", 1.0)) * r_orc
    elif baseline in {"betop", "betop_lite", "betopnet", "betopnet_lite"}:
        topo_values = []
        for d in samples:
            arr = _actor_topology_arrays(d, cfg)[1]
            topo_values.append(float(arr.max() if arr.size else 0.0))
        topo_hit = np.asarray(topo_values, dtype=np.float32)
        score = utility - float(bcfg.get("hard_weight", 12.0)) * hard - float(bcfg.get("harm_weight", 2.0)) * harm + float(bcfg.get("oracle_weight", 0.6)) * r_orc + float(bcfg.get("topology_weight", 0.5)) * topo_hit
    elif baseline in {"risk_net", "risk_aware_net"}:
        score = utility - float(bcfg.get("hard_weight", 12.0)) * hard - float(bcfg.get("harm_weight", 2.0)) * harm + float(bcfg.get("deploy_weight", 0.5)) * r_dep
    else:
        score = utility
    score = np.where(feasible, score, -1.0e9)
    return int(np.argmax(score)) if score.size else 0


class ExternalGroupDataset(Dataset):
    """Dataset of candidate-prefix sets grouped by scene/time."""

    def __init__(self, dataset: str | Path, cfg: dict[str, Any], *, split: str = "train", baseline: str = "route_bc_lite"):
        self.cfg = cfg
        self.baseline = str(baseline)
        self.groups = group_sample_paths(dataset, split=split)
        if not self.groups:
            raise ValueError(f"No grouped samples found in {dataset!s} for split={split!r}")
        first = load_npz(self.groups[0][0])
        self.feature_dim = int(sample_to_feature(first, cfg).shape[0])
        bcfg = cfg.get("external_baselines", {}) if isinstance(cfg.get("external_baselines", {}), dict) else {}
        self.max_candidates = int(bcfg.get("max_candidates", max(len(g) for g in self.groups)))
        m0, rf0, _, _, _ = _branch_arrays(first, cfg)
        self.num_roots = int(m0.shape[0])
        self.num_options = int(m0.shape[1])
        self.root_feature_dim = int(rf0.shape[-1])
        ego0, neigh0, _, prefix0, _ = _history_arrays(first, cfg)
        self.history_len = int(ego0.shape[0])
        self.neighbors_to_predict = int(neigh0.shape[0])
        self.future_len = int(prefix0.shape[0])
        at0, _, _ = _actor_topology_arrays(first, cfg)
        mt0, _, _ = _map_topology_arrays(first, cfg)
        self.num_topology_agents = int(at0.shape[0])
        self.actor_topology_feature_dim = int(at0.shape[-1])
        self.num_topology_map = int(mt0.shape[0])
        self.map_topology_feature_dim = int(mt0.shape[-1])
        # Backwards-compatible names used by train/evaluate checkpoints.
        self.topology_feature_dim = self.actor_topology_feature_dim

    def __len__(self) -> int:
        return len(self.groups)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        paths = self.groups[idx][: self.max_candidates]
        samples = [load_npz(p) for p in paths]
        n = len(samples)
        x = np.zeros((self.max_candidates, self.feature_dim), dtype=np.float32)
        mask = np.zeros((self.max_candidates,), dtype=bool)
        utility = np.zeros((self.max_candidates,), dtype=np.float32)
        hard = np.zeros((self.max_candidates,), dtype=np.float32)
        harm = np.zeros((self.max_candidates,), dtype=np.float32)
        r_orc = np.zeros((self.max_candidates,), dtype=np.float32)
        r_dep = np.zeros((self.max_candidates,), dtype=np.float32)
        feasible = np.zeros((self.max_candidates,), dtype=bool)
        branch_margins = np.zeros((self.max_candidates, self.num_roots, self.num_options), dtype=np.float32)
        root_features = np.zeros((self.max_candidates, self.num_roots, self.root_feature_dim), dtype=np.float32)
        root_probs = np.zeros((self.max_candidates, self.num_roots), dtype=np.float32)
        root_valid = np.zeros((self.max_candidates, self.num_roots), dtype=bool)
        option_valid = np.zeros((self.max_candidates, self.num_options), dtype=bool)

        ego_history = np.zeros((self.max_candidates, self.history_len, GAMEFORMER_STATE_DIM), dtype=np.float32)
        neighbor_history = np.zeros((self.max_candidates, self.neighbors_to_predict, self.history_len, GAMEFORMER_STATE_DIM), dtype=np.float32)
        neighbor_valid = np.zeros((self.max_candidates, self.neighbors_to_predict, self.history_len), dtype=bool)
        prefix_traj = np.zeros((self.max_candidates, self.future_len, 2), dtype=np.float32)
        prefix_valid = np.zeros((self.max_candidates, self.future_len), dtype=bool)

        actor_topology_features = np.zeros((self.max_candidates, self.num_topology_agents, self.actor_topology_feature_dim), dtype=np.float32)
        actor_topology_target = np.zeros((self.max_candidates, self.num_topology_agents), dtype=np.float32)
        actor_topology_mask = np.zeros((self.max_candidates, self.num_topology_agents), dtype=bool)
        map_topology_features = np.zeros((self.max_candidates, self.num_topology_map, self.map_topology_feature_dim), dtype=np.float32)
        map_topology_target = np.zeros((self.max_candidates, self.num_topology_map), dtype=np.float32)
        map_topology_mask = np.zeros((self.max_candidates, self.num_topology_map), dtype=bool)

        for i, d in enumerate(samples):
            x[i] = sample_to_feature(d, self.cfg)
            mask[i] = True
            utility[i] = _scalar(d, "utility", 0.0)
            hard[i] = _scalar(d, "hard_violation", 0.0)
            harm[i] = _scalar(d, "harm_proxy", 0.0)
            r_orc[i] = _scalar(d, "r_orc_star", 0.0)
            r_dep[i] = _scalar(d, "r_dep_star", 0.0)
            feasible[i] = _scalar(d, "feasible", 1.0) > 0.5
            bm, rf, rp, rv, ov = _branch_arrays(d, self.cfg)
            branch_margins[i] = bm
            root_features[i] = rf
            root_probs[i] = rp
            root_valid[i] = rv
            option_valid[i] = ov
            eh, nh, nv, pt, pv = _history_arrays(d, self.cfg)
            ego_history[i] = eh
            neighbor_history[i] = nh
            neighbor_valid[i] = nv
            prefix_traj[i] = pt
            prefix_valid[i] = pv
            af, at, am = _actor_topology_arrays(d, self.cfg)
            mf, mt, mm = _map_topology_arrays(d, self.cfg)
            actor_topology_features[i] = af
            actor_topology_target[i] = at
            actor_topology_mask[i] = am
            map_topology_features[i] = mf
            map_topology_target[i] = mt
            map_topology_mask[i] = mm

        target = min(_target_index(samples, self.baseline, self.cfg), max(n - 1, 0))
        return {
            "x": torch.from_numpy(x),
            "mask": torch.from_numpy(mask),
            "target_index": torch.tensor(target, dtype=torch.long),
            "utility": torch.from_numpy(utility),
            "hard": torch.from_numpy(hard),
            "harm": torch.from_numpy(harm),
            "r_orc": torch.from_numpy(r_orc),
            "r_dep": torch.from_numpy(r_dep),
            "feasible": torch.from_numpy(feasible),
            "branch_margins": torch.from_numpy(branch_margins),
            "root_features": torch.from_numpy(root_features),
            "root_probs": torch.from_numpy(root_probs),
            "root_valid": torch.from_numpy(root_valid),
            "option_valid": torch.from_numpy(option_valid),
            "ego_history": torch.from_numpy(ego_history),
            "neighbor_history": torch.from_numpy(neighbor_history),
            "neighbor_valid": torch.from_numpy(neighbor_valid),
            "prefix_traj": torch.from_numpy(prefix_traj),
            "prefix_valid": torch.from_numpy(prefix_valid),
            "actor_topology_features": torch.from_numpy(actor_topology_features),
            "actor_topology_target": torch.from_numpy(actor_topology_target),
            "actor_topology_mask": torch.from_numpy(actor_topology_mask),
            "map_topology_features": torch.from_numpy(map_topology_features),
            "map_topology_target": torch.from_numpy(map_topology_target),
            "map_topology_mask": torch.from_numpy(map_topology_mask),
            # Legacy aliases.
            "topology_features": torch.from_numpy(actor_topology_features),
            "topology_target": torch.from_numpy(actor_topology_target.astype(np.int64)),
            "topology_mask": torch.from_numpy(actor_topology_mask),
        }
