from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch import nn
import torch.nn.functional as F


ACTOR_TOPO_FEATURE_DIM = 16
MAP_TOPO_FEATURE_DIM = 14
GAMEFORMER_STATE_DIM = 9


@dataclass
class ExternalBaselineBatch:
    x: torch.Tensor
    mask: torch.Tensor
    target_index: torch.Tensor
    utility: torch.Tensor
    hard: torch.Tensor
    harm: torch.Tensor
    r_orc: torch.Tensor
    r_dep: torch.Tensor
    feasible: torch.Tensor
    branch_margins: torch.Tensor | None = None
    root_features: torch.Tensor | None = None
    root_probs: torch.Tensor | None = None
    root_valid: torch.Tensor | None = None
    option_valid: torch.Tensor | None = None
    ego_history: torch.Tensor | None = None
    neighbor_history: torch.Tensor | None = None
    neighbor_valid: torch.Tensor | None = None
    prefix_traj: torch.Tensor | None = None
    prefix_valid: torch.Tensor | None = None
    actor_topology_features: torch.Tensor | None = None
    actor_topology_target: torch.Tensor | None = None
    actor_topology_mask: torch.Tensor | None = None
    map_topology_features: torch.Tensor | None = None
    map_topology_target: torch.Tensor | None = None
    map_topology_mask: torch.Tensor | None = None


class ResidualMLP(nn.Module):
    def __init__(self, d_model: int, hidden_dim: int = 128, num_layers: int = 4, dropout: float = 0.1, out_dim: int = 1) -> None:
        super().__init__()
        self.in_proj = nn.Linear(d_model, hidden_dim)
        self.layers = nn.ModuleList([
            nn.Sequential(
                nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim), nn.Dropout(dropout),
            )
            for _ in range(int(num_layers))
        ])
        self.out = nn.Linear(hidden_dim, out_dim)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        z = self.in_proj(h)
        for block in self.layers:
            z = z + block(z)
        return self.out(F.gelu(z))


class ScalarHeads(nn.Module):
    def __init__(self, d_model: int) -> None:
        super().__init__()
        self.utility = nn.Linear(d_model, 1)
        self.hard = nn.Linear(d_model, 1)
        self.harm = nn.Linear(d_model, 1)
        self.r_orc = nn.Linear(d_model, 1)
        self.r_dep = nn.Linear(d_model, 1)

    def forward(self, h: torch.Tensor) -> dict[str, torch.Tensor]:
        return {
            "utility": self.utility(h).squeeze(-1),
            "hard": self.hard(h).squeeze(-1),
            "harm": self.harm(h).squeeze(-1),
            "r_orc": self.r_orc(h).squeeze(-1),
            "r_dep": self.r_dep(h).squeeze(-1),
        }


class WayformerRouteBC(nn.Module):
    """Route-conditioned behavior cloning baseline with Wayformer-style latents."""

    def __init__(self, input_dim: int, max_candidates: int = 32, d_model: int = 256, num_layers: int = 4, num_heads: int = 8, dropout: float = 0.15, mlp_hidden: int = 128, mlp_layers: int = 4, num_latents: int = 16) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.max_candidates = int(max_candidates)
        self.d_model = int(d_model)
        self.num_latents = int(num_latents)
        self.token_proj = nn.Sequential(nn.LayerNorm(self.input_dim), nn.Linear(self.input_dim, d_model), nn.GELU(), nn.Dropout(dropout))
        self.pos = nn.Parameter(torch.zeros(1, self.max_candidates, d_model))
        self.type_route = nn.Parameter(torch.zeros(1, 1, d_model))
        enc_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=int(num_heads), dim_feedforward=4 * d_model, dropout=float(dropout), activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=int(num_layers))
        if self.num_latents > 0:
            self.latents = nn.Parameter(torch.randn(1, self.num_latents, d_model) * 0.02)
            self.latent_xattn = nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True)
            self.token_xattn = nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True)
            self.latent_norm = nn.LayerNorm(d_model)
        else:
            self.latents = None
            self.latent_xattn = None
            self.token_xattn = None
            self.latent_norm = None
        self.norm = nn.LayerNorm(d_model)
        self.policy_head = ResidualMLP(d_model, hidden_dim=int(mlp_hidden), num_layers=int(mlp_layers), dropout=float(dropout), out_dim=1)
        self.scalar_heads = ScalarHeads(d_model)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None, **_: torch.Tensor) -> dict[str, torch.Tensor]:
        B, N, _ = x.shape
        h = self.token_proj(x) + self._position(N) + self.type_route
        key_padding_mask = None if mask is None else ~mask.bool()
        h = self.encoder(h, src_key_padding_mask=key_padding_mask)
        if self.num_latents > 0 and self.latents is not None:
            lat = self.latents.expand(B, -1, -1)
            lat, _ = self.latent_xattn(lat, h, h, key_padding_mask=key_padding_mask, need_weights=False)
            lat = self.latent_norm(lat)
            h2, _ = self.token_xattn(h, lat, lat, need_weights=False)
            h = h + h2
        h = self.norm(h)
        logits = self.policy_head(h).squeeze(-1)
        if mask is not None:
            logits = logits.masked_fill(~mask.bool(), -1.0e4)
        out = {"logits": logits}
        out.update(self.scalar_heads(h))
        return out

    def _position(self, N: int) -> torch.Tensor:
        if N > self.pos.shape[1]:
            extra = self.pos[:, -1:, :].expand(1, N - self.pos.shape[1], -1)
            return torch.cat([self.pos, extra], dim=1)[:, :N]
        return self.pos[:, :N]


class GameFormerFutureEncoder(nn.Module):
    """FutureEncoder analogue from the uploaded GameFormer source."""

    def __init__(self, d_model: int, future_len: int, dropout: float) -> None:
        super().__init__()
        self.future_len = int(future_len)
        # Per-step state: x,y,heading,vx,vy,width,length,valid-like channel.
        self.step_mlp = nn.Sequential(nn.Linear(8, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))
        self.pool = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model), nn.GELU())

    def forward(self, traj_xy: torch.Tensor, scores: torch.Tensor) -> torch.Tensor:
        # traj_xy: [B,N,M,T,2], scores: [B,N,M]
        B, N, M, T, _ = traj_xy.shape
        prev = torch.cat([traj_xy[..., :1, :], traj_xy[..., :-1, :]], dim=-2)
        dxy = traj_xy - prev
        vel = dxy / 0.1
        heading = torch.atan2(dxy[..., 1], dxy[..., 0].clamp(min=1e-3)).unsqueeze(-1)
        size = torch.ones(B, N, M, T, 2, device=traj_xy.device, dtype=traj_xy.dtype)
        valid = torch.ones(B, N, M, T, 1, device=traj_xy.device, dtype=traj_xy.dtype)
        state = torch.cat([traj_xy, heading, vel, size, valid], dim=-1)
        step = self.step_mlp(state)
        pooled = step.max(dim=-2).values
        weights = torch.softmax(scores, dim=-1).unsqueeze(-1)
        return self.pool((pooled * weights).sum(dim=2))


class GameFormerLevelK(nn.Module):
    """GameFormer adapter that preserves encoder, multi-modal decoding and level-k reasoning.

    The uploaded GameFormer source uses AgentEncoder/LaneEncoder/CrosswalkEncoder,
    a Transformer fusion encoder, an InitialDecoder with learned modal/agent
    queries, then InteractionDecoder blocks whose FutureEncoder consumes the
    previous level's trajectories.  This adapter implements the same algorithmic
    pattern over OC-RAP grouped candidate-prefix tensors.
    """

    def __init__(self, input_dim: int, max_candidates: int = 32, d_model: int = 256, num_layers: int = 3, num_heads: int = 8, dropout: float = 0.15, num_levels: int = 4, modalities: int = 6, future_len: int = 20, history_len: int = 11, neighbors_to_predict: int = 8, root_feature_dim: int = 18, num_roots: int = 10, num_options: int = 12) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.max_candidates = int(max_candidates)
        self.d_model = int(d_model)
        self.num_levels = int(num_levels)
        self.modalities = int(modalities)
        self.future_len = int(future_len)
        self.history_len = int(history_len)
        self.neighbors_to_predict = int(neighbors_to_predict)
        self.num_roots = int(num_roots)
        self.num_options = int(num_options)
        self.root_feature_dim = int(root_feature_dim)

        self.candidate_proj = nn.Sequential(nn.LayerNorm(input_dim), nn.Linear(input_dim, d_model), nn.GELU(), nn.Dropout(dropout))
        self.pos = nn.Parameter(torch.zeros(1, self.max_candidates, d_model))
        self.ego_encoder = nn.LSTM(GAMEFORMER_STATE_DIM, d_model // 2, num_layers=2, batch_first=True, dropout=dropout)
        self.agent_encoder = nn.LSTM(GAMEFORMER_STATE_DIM, d_model // 2, num_layers=2, batch_first=True, dropout=dropout)
        self.history_fuse = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))
        enc_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=int(num_heads), dim_feedforward=4 * d_model, dropout=float(dropout), activation="gelu", batch_first=True, norm_first=True)
        self.fusion_encoder = nn.TransformerEncoder(enc_layer, num_layers=int(num_layers))

        branch_in = self.root_feature_dim + self.num_options + 2
        self.branch_point = nn.Sequential(nn.LayerNorm(branch_in), nn.Linear(branch_in, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))
        self.branch_pool = nn.Linear(d_model, d_model)

        self.modal_query = nn.Embedding(self.modalities, d_model)
        self.level0_cross = nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True)
        self.level_cross = nn.ModuleList([nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True) for _ in range(max(self.num_levels, 1))])
        self.level_self = nn.ModuleList([
            nn.TransformerEncoder(nn.TransformerEncoderLayer(d_model=d_model, nhead=int(num_heads), dim_feedforward=4*d_model, dropout=float(dropout), activation="gelu", batch_first=True, norm_first=True), num_layers=1)
            for _ in range(max(self.num_levels, 1))
        ])
        self.future_encoder = GameFormerFutureEncoder(d_model, self.future_len, dropout)
        self.content_norm = nn.LayerNorm(d_model)
        self.traj_heads = nn.ModuleList([nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model), nn.ELU(), nn.Dropout(dropout), nn.Linear(d_model, self.future_len * 4)) for _ in range(self.num_levels + 1)])
        self.score_heads = nn.ModuleList([nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model // 2), nn.ELU(), nn.Dropout(dropout), nn.Linear(d_model // 2, 1)) for _ in range(self.num_levels + 1)])
        self.policy_heads = nn.ModuleList([nn.Linear(d_model, 1) for _ in range(self.num_levels + 1)])
        self.scalar_heads = ScalarHeads(d_model)
        self.final_norm = nn.LayerNorm(d_model)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None, *, branch_margins: torch.Tensor | None = None, root_features: torch.Tensor | None = None, root_probs: torch.Tensor | None = None, root_valid: torch.Tensor | None = None, ego_history: torch.Tensor | None = None, neighbor_history: torch.Tensor | None = None, neighbor_valid: torch.Tensor | None = None, **_: torch.Tensor) -> dict[str, torch.Tensor]:
        B, N, _ = x.shape
        key_padding_mask = None if mask is None else ~mask.bool()
        scene = self.candidate_proj(x) + self._position(N)
        hist_ctx = self._encode_history(B, N, x.device, ego_history, neighbor_history, neighbor_valid)
        branch_ctx = self._encode_branch(B, N, x.device, branch_margins, root_features, root_probs, root_valid)
        scene = scene + hist_ctx + branch_ctx
        scene = self.fusion_encoder(scene, src_key_padding_mask=key_padding_mask)

        content, traj, scores = self._initial_decode(scene, mask)
        level_logits: list[torch.Tensor] = []
        level_trajs: list[torch.Tensor] = []
        level_scores: list[torch.Tensor] = []
        logits0 = self._candidate_logits(content, scores, 0, mask)
        level_logits.append(logits0)
        level_trajs.append(traj)
        level_scores.append(scores)

        for k in range(1, self.num_levels + 1):
            future_ctx = self.future_encoder(traj[..., :2], scores)
            inter_ctx = self.level_self[k - 1](future_ctx, src_key_padding_mask=key_padding_mask)
            q = content + scene[:, :, None, :] + inter_ctx[:, :, None, :]
            q = q.reshape(B * N, self.modalities, self.d_model)
            mem = scene[:, None, :, :].expand(B, N, N, self.d_model).reshape(B * N, N, self.d_model)
            kmask = key_padding_mask[:, None, :].expand(B, N, N).reshape(B * N, N) if key_padding_mask is not None else None
            q2, _ = self.level_cross[k - 1](q, mem, mem, key_padding_mask=kmask, need_weights=False)
            content = self.content_norm((q + q2).reshape(B, N, self.modalities, self.d_model))
            traj, scores = self._predict_traj(content, k)
            level_logits.append(self._candidate_logits(content, scores, k, mask))
            level_trajs.append(traj)
            level_scores.append(scores)

        h = self.final_norm(scene + content.mean(dim=2))
        out = {
            "logits": level_logits[-1],
            "level_logits": level_logits,
            "gameformer_level_trajs": level_trajs,
            "gameformer_level_scores": level_scores,
        }
        out.update(self.scalar_heads(h))
        return out

    def _position(self, N: int) -> torch.Tensor:
        if N > self.pos.shape[1]:
            extra = self.pos[:, -1:, :].expand(1, N - self.pos.shape[1], -1)
            return torch.cat([self.pos, extra], dim=1)[:, :N]
        return self.pos[:, :N]

    def _encode_history(self, B: int, N: int, device: torch.device, ego_history: torch.Tensor | None, neighbor_history: torch.Tensor | None, neighbor_valid: torch.Tensor | None) -> torch.Tensor:
        if ego_history is None:
            return torch.zeros(B, N, self.d_model, device=device)
        ego = ego_history.to(device=device, dtype=torch.float32)
        ego = self._pad_last2(ego, self.history_len, GAMEFORMER_STATE_DIM)
        ego_flat = ego.reshape(B * N, self.history_len, GAMEFORMER_STATE_DIM)
        _, (ego_h, _) = self.ego_encoder(ego_flat)
        ego_ctx = ego_h[-1].reshape(B, N, -1)
        if neighbor_history is None:
            neigh_ctx = torch.zeros(B, N, self.d_model // 2, device=device)
        else:
            neigh = neighbor_history.to(device=device, dtype=torch.float32)
            neigh = self._pad_last3(neigh, self.neighbors_to_predict, self.history_len, GAMEFORMER_STATE_DIM)
            neigh_flat = neigh.reshape(B * N * self.neighbors_to_predict, self.history_len, GAMEFORMER_STATE_DIM)
            _, (nh, _) = self.agent_encoder(neigh_flat)
            nh = nh[-1].reshape(B, N, self.neighbors_to_predict, -1)
            if neighbor_valid is not None:
                nv = self._pad_last2(neighbor_valid.to(device=device, dtype=torch.float32), self.neighbors_to_predict, self.history_len)
                w = (nv.sum(dim=-1) > 0).float().unsqueeze(-1)
            else:
                w = torch.ones(B, N, self.neighbors_to_predict, 1, device=device)
            neigh_ctx = (nh * w).sum(dim=2) / w.sum(dim=2).clamp_min(1.0)
        return self.history_fuse(torch.cat([ego_ctx, neigh_ctx], dim=-1))

    def _encode_branch(self, B: int, N: int, device: torch.device, branch_margins: torch.Tensor | None, root_features: torch.Tensor | None, root_probs: torch.Tensor | None, root_valid: torch.Tensor | None) -> torch.Tensor:
        K, L, Fdim = self.num_roots, self.num_options, self.root_feature_dim
        if root_features is None:
            root_features = torch.zeros(B, N, K, Fdim, device=device)
        else:
            root_features = self._pad_last2(root_features.to(device=device, dtype=torch.float32), K, Fdim)
        if branch_margins is None:
            branch_margins = torch.zeros(B, N, K, L, device=device)
        else:
            branch_margins = self._pad_last2(branch_margins.to(device=device, dtype=torch.float32), K, L)
            branch_margins = torch.nan_to_num(branch_margins, nan=0.0, posinf=5.0, neginf=-5.0).clamp(-5.0, 5.0)
        if root_probs is None:
            root_probs = torch.full((B, N, K), 1.0 / max(K, 1), device=device)
        else:
            root_probs = self._pad_1d(root_probs.to(device=device, dtype=torch.float32), K).clamp_min(0.0)
        if root_valid is None:
            root_valid = torch.ones(B, N, K, device=device, dtype=torch.float32)
        else:
            root_valid = self._pad_1d(root_valid.to(device=device, dtype=torch.float32), K)
        root_probs = root_probs * (root_valid > 0.5).float()
        root_probs = root_probs / root_probs.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        point = torch.cat([root_features, branch_margins, root_probs.unsqueeze(-1), root_valid.unsqueeze(-1)], dim=-1)
        enc = self.branch_point(point)
        return self.branch_pool((enc * root_probs.unsqueeze(-1)).sum(dim=2))

    def _initial_decode(self, scene: torch.Tensor, mask: torch.Tensor | None) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        B, N, _ = scene.shape
        modal = self.modal_query.weight[None, None, :, :].expand(B, N, self.modalities, self.d_model)
        q = scene[:, :, None, :] + modal
        q_flat = q.reshape(B * N, self.modalities, self.d_model)
        mem = scene[:, None, :, :].expand(B, N, N, self.d_model).reshape(B * N, N, self.d_model)
        kmask = (~mask.bool())[:, None, :].expand(B, N, N).reshape(B * N, N) if mask is not None else None
        q2, _ = self.level0_cross(q_flat, mem, mem, key_padding_mask=kmask, need_weights=False)
        content = self.content_norm((q_flat + q2).reshape(B, N, self.modalities, self.d_model))
        traj, scores = self._predict_traj(content, 0)
        return content, traj, scores

    def _predict_traj(self, content: torch.Tensor, level: int) -> tuple[torch.Tensor, torch.Tensor]:
        B, N, M, _ = content.shape
        raw = self.traj_heads[level](content).view(B, N, M, self.future_len, 4)
        # Cumulative displacement gives dynamically smoother trajectories than
        # unconstrained absolute points and mirrors GameFormer's trajectory head.
        xy = torch.cumsum(raw[..., :2], dim=-2)
        logsig = raw[..., 2:4].clamp(-5.0, 5.0)
        traj = torch.cat([xy, logsig], dim=-1)
        scores = self.score_heads[level](content).squeeze(-1)
        return traj, scores

    def _candidate_logits(self, content: torch.Tensor, scores: torch.Tensor, level: int, mask: torch.Tensor | None) -> torch.Tensor:
        h = content.mean(dim=2)
        logits = self.policy_heads[level](h).squeeze(-1) + torch.logsumexp(scores, dim=-1)
        if mask is not None:
            logits = logits.masked_fill(~mask.bool(), -1.0e4)
        return logits

    @staticmethod
    def _pad_1d(x: torch.Tensor, n: int) -> torch.Tensor:
        if x.shape[-1] == n:
            return x
        out = x.new_zeros(*x.shape[:-1], n)
        m = min(n, x.shape[-1])
        if m > 0:
            out[..., :m] = x[..., :m]
        return out

    @staticmethod
    def _pad_last2(x: torch.Tensor, n0: int, n1: int) -> torch.Tensor:
        if x.shape[-2] == n0 and x.shape[-1] == n1:
            return x
        out = x.new_zeros(*x.shape[:-2], n0, n1)
        m0 = min(n0, x.shape[-2]); m1 = min(n1, x.shape[-1])
        if m0 > 0 and m1 > 0:
            out[..., :m0, :m1] = x[..., :m0, :m1]
        return out

    @staticmethod
    def _pad_last3(x: torch.Tensor, n0: int, n1: int, n2: int) -> torch.Tensor:
        if x.shape[-3:] == (n0, n1, n2):
            return x
        out = x.new_zeros(*x.shape[:-3], n0, n1, n2)
        m0 = min(n0, x.shape[-3]); m1 = min(n1, x.shape[-2]); m2 = min(n2, x.shape[-1])
        if m0 > 0 and m1 > 0 and m2 > 0:
            out[..., :m0, :m1, :m2] = x[..., :m0, :m1, :m2]
        return out


class TopoFuser(nn.Module):
    """Compact counterpart of BeTop's TopoFuser."""

    def __init__(self, d_model: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(nn.LayerNorm(3 * d_model), nn.Linear(3 * d_model, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))

    def forward(self, src: torch.Tensor, tgt: torch.Tensor, prev: torch.Tensor | None) -> torch.Tensor:
        if prev is None:
            prev = torch.zeros_like(tgt)
        return self.net(torch.cat([src, tgt, prev], dim=-1))


class BeTopNetLite(nn.Module):
    """BeTopNet adapter preserving behavioral topology reasoning.

    The uploaded BeTopNet source builds an MTR-style encoder/decoder, predicts
    actor and map topology, selects topological neighbors, applies topology-aware
    attention, and uses focal/top-k topology losses.  This adapter keeps those
    core mechanisms while consuming OC-RAP grouped candidate tensors instead of
    BeTop's native WOMD cache.
    """

    def __init__(self, input_dim: int, max_candidates: int = 32, d_model: int = 256, num_layers: int = 3, num_heads: int = 8, dropout: float = 0.15, actor_topology_feature_dim: int = ACTOR_TOPO_FEATURE_DIM, map_topology_feature_dim: int = MAP_TOPO_FEATURE_DIM, num_topology_agents: int = 16, num_topology_map: int = 64, num_topo: int = 16, mlp_hidden: int = 128, mlp_layers: int = 3) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.max_candidates = int(max_candidates)
        self.d_model = int(d_model)
        self.num_topology_agents = int(num_topology_agents)
        self.num_topology_map = int(num_topology_map)
        self.actor_topology_feature_dim = int(actor_topology_feature_dim)
        self.map_topology_feature_dim = int(map_topology_feature_dim)
        self.num_topo = int(num_topo)
        self.token_proj = nn.Sequential(nn.LayerNorm(input_dim), nn.Linear(input_dim, d_model), nn.GELU(), nn.Dropout(dropout))
        self.pos = nn.Parameter(torch.zeros(1, self.max_candidates, d_model))
        enc_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=int(num_heads), dim_feedforward=4 * d_model, dropout=float(dropout), activation="gelu", batch_first=True, norm_first=True)
        self.scene_encoder = nn.TransformerEncoder(enc_layer, num_layers=int(num_layers))

        self.actor_proj = nn.Sequential(nn.LayerNorm(self.actor_topology_feature_dim), nn.Linear(self.actor_topology_feature_dim, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))
        self.map_proj = nn.Sequential(nn.LayerNorm(self.map_topology_feature_dim), nn.Linear(self.map_topology_feature_dim, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, d_model))
        self.actor_fusers = nn.ModuleList([TopoFuser(d_model, dropout) for _ in range(int(num_layers))])
        self.map_fusers = nn.ModuleList([TopoFuser(d_model, dropout) for _ in range(int(num_layers))])
        self.actor_topo_decoders = nn.ModuleList([nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model // 2), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model // 2, 1)) for _ in range(int(num_layers))])
        self.map_topo_decoders = nn.ModuleList([nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model // 2), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model // 2, 1)) for _ in range(int(num_layers))])
        self.actor_attn = nn.ModuleList([nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True) for _ in range(int(num_layers))])
        self.map_attn = nn.ModuleList([nn.MultiheadAttention(d_model, int(num_heads), dropout=float(dropout), batch_first=True) for _ in range(int(num_layers))])
        self.update_norm = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(int(num_layers))])
        self.policy_head = ResidualMLP(d_model, hidden_dim=int(mlp_hidden), num_layers=int(mlp_layers), dropout=float(dropout), out_dim=1)
        self.scalar_heads = ScalarHeads(d_model)
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None, *, actor_topology_features: torch.Tensor | None = None, actor_topology_mask: torch.Tensor | None = None, map_topology_features: torch.Tensor | None = None, map_topology_mask: torch.Tensor | None = None, topology_features: torch.Tensor | None = None, topology_mask: torch.Tensor | None = None, **_: torch.Tensor) -> dict[str, torch.Tensor]:
        B, N, _ = x.shape
        key_padding_mask = None if mask is None else ~mask.bool()
        h = self.token_proj(x) + self._position(N)
        h = self.scene_encoder(h, src_key_padding_mask=key_padding_mask)

        if actor_topology_features is None and topology_features is not None:
            actor_topology_features = topology_features
        if actor_topology_mask is None and topology_mask is not None:
            actor_topology_mask = topology_mask
        actor_mem, actor_mask = self._topology_memory(B, N, x.device, actor_topology_features, actor_topology_mask, self.num_topology_agents, self.actor_topology_feature_dim, self.actor_proj)
        map_mem, map_mask = self._topology_memory(B, N, x.device, map_topology_features, map_topology_mask, self.num_topology_map, self.map_topology_feature_dim, self.map_proj)

        actor_prev: torch.Tensor | None = None
        map_prev: torch.Tensor | None = None
        actor_logits_levels: list[torch.Tensor] = []
        map_logits_levels: list[torch.Tensor] = []
        for i in range(len(self.actor_fusers)):
            src_actor = h[:, :, None, :].expand(B, N, self.num_topology_agents, self.d_model)
            actor_feat = self.actor_fusers[i](src_actor, actor_mem, actor_prev)
            actor_logits = self.actor_topo_decoders[i](actor_feat).squeeze(-1)
            actor_logits = actor_logits.masked_fill(~actor_mask.bool(), -1.0e4)
            actor_prev = actor_feat
            h = self._apply_topo_attention(h, actor_mem, actor_logits, actor_mask, self.actor_attn[i], mask)

            src_map = h[:, :, None, :].expand(B, N, self.num_topology_map, self.d_model)
            map_feat = self.map_fusers[i](src_map, map_mem, map_prev)
            map_logits = self.map_topo_decoders[i](map_feat).squeeze(-1)
            map_logits = map_logits.masked_fill(~map_mask.bool(), -1.0e4)
            map_prev = map_feat
            h = self._apply_topo_attention(h, map_mem, map_logits, map_mask, self.map_attn[i], mask)
            h = self.update_norm[i](h)
            actor_logits_levels.append(actor_logits)
            map_logits_levels.append(map_logits)

        h = self.norm(h)
        logits = self.policy_head(h).squeeze(-1)
        if mask is not None:
            logits = logits.masked_fill(~mask.bool(), -1.0e4)
        out = {
            "logits": logits,
            "actor_topo_logits": actor_logits_levels[-1].unsqueeze(-1),
            "map_topo_logits": map_logits_levels[-1].unsqueeze(-1),
            "actor_topo_logits_levels": [z.unsqueeze(-1) for z in actor_logits_levels],
            "map_topo_logits_levels": [z.unsqueeze(-1) for z in map_logits_levels],
            # Legacy key for old policy code; shape [B,N,A,1].
            "topology_logits": actor_logits_levels[-1].unsqueeze(-1),
        }
        out.update(self.scalar_heads(h))
        return out

    def _position(self, N: int) -> torch.Tensor:
        if N > self.pos.shape[1]:
            extra = self.pos[:, -1:, :].expand(1, N - self.pos.shape[1], -1)
            return torch.cat([self.pos, extra], dim=1)[:, :N]
        return self.pos[:, :N]

    def _topology_memory(self, B: int, N: int, device: torch.device, feats: torch.Tensor | None, mask: torch.Tensor | None, count: int, fdim: int, proj: nn.Module) -> tuple[torch.Tensor, torch.Tensor]:
        if feats is None:
            feats = torch.zeros(B, N, count, fdim, device=device)
        else:
            feats = self._pad_last2(feats.to(device=device, dtype=torch.float32), count, fdim)
        if mask is None:
            mask = feats.abs().sum(dim=-1) > 0
        else:
            mask = self._pad_1d(mask.to(device=device, dtype=torch.float32), count) > 0.5
        return proj(feats), mask.bool()

    def _apply_topo_attention(self, h: torch.Tensor, mem: torch.Tensor, logits: torch.Tensor, valid_mask: torch.Tensor, attn: nn.MultiheadAttention, cand_mask: torch.Tensor | None) -> torch.Tensor:
        B, N, Kall, D = mem.shape
        k = min(max(1, self.num_topo), Kall)
        score = torch.sigmoid(logits).masked_fill(~valid_mask.bool(), -1.0)
        idx = torch.topk(score, k=k, dim=-1).indices
        gather = idx.unsqueeze(-1).expand(B, N, k, D)
        selected = torch.gather(mem, dim=2, index=gather).reshape(B * N, k, D)
        q = h.reshape(B * N, 1, D)
        attn_mask = None
        out, _ = attn(q, selected, selected, key_padding_mask=attn_mask, need_weights=False)
        out = out.reshape(B, N, D)
        if cand_mask is not None:
            out = out * cand_mask.bool().unsqueeze(-1).float()
        return h + out

    @staticmethod
    def _pad_1d(x: torch.Tensor, n: int) -> torch.Tensor:
        if x.shape[-1] == n:
            return x
        out = x.new_zeros(*x.shape[:-1], n)
        m = min(n, x.shape[-1])
        if m > 0:
            out[..., :m] = x[..., :m]
        return out

    @staticmethod
    def _pad_last2(x: torch.Tensor, n0: int, n1: int) -> torch.Tensor:
        if x.shape[-2] == n0 and x.shape[-1] == n1:
            return x
        out = x.new_zeros(*x.shape[:-2], n0, n1)
        m0 = min(n0, x.shape[-2]); m1 = min(n1, x.shape[-1])
        if m0 > 0 and m1 > 0:
            out[..., :m0, :m1] = x[..., :m0, :m1]
        return out


CandidateSetTransformer = WayformerRouteBC


def build_model_from_cfg(input_dim: int, cfg: dict[str, Any]) -> nn.Module:
    bcfg = cfg.get("external_baselines", {}) if isinstance(cfg.get("external_baselines", {}), dict) else {}
    mcfg = bcfg.get("model", {}) if isinstance(bcfg.get("model", {}), dict) else {}
    baseline = str(bcfg.get("baseline", "route_bc_lite")).lower()
    arch = str(mcfg.get("arch", "")).lower()
    max_candidates = int(mcfg.get("max_candidates", bcfg.get("max_candidates", 32)))
    common = dict(
        input_dim=int(input_dim),
        max_candidates=max_candidates,
        d_model=int(mcfg.get("d_model", 256 if ("gameformer" in baseline or "betop" in baseline) else 192)),
        num_layers=int(mcfg.get("num_layers", 3)),
        num_heads=int(mcfg.get("num_heads", 4)),
        dropout=float(mcfg.get("dropout", 0.15)),
    )
    if arch in {"gameformer", "gameformer_levelk", "levelk"} or "gameformer" in baseline:
        return GameFormerLevelK(
            **common,
            num_levels=int(mcfg.get("num_levels", 4)),
            modalities=int(mcfg.get("modalities", 6)),
            future_len=int(mcfg.get("future_len", 20)),
            history_len=int(mcfg.get("history_len", 11)),
            neighbors_to_predict=int(mcfg.get("neighbors_to_predict", 8)),
            root_feature_dim=int(mcfg.get("root_feature_dim", 18)),
            num_roots=int(mcfg.get("num_roots", cfg.get("num_roots", 10))),
            num_options=int(mcfg.get("num_options", cfg.get("num_recovery_options", 12))),
        )
    if arch in {"betop", "betop_lite", "betopnet", "betopnet_lite"} or "betop" in baseline:
        return BeTopNetLite(
            **common,
            actor_topology_feature_dim=int(mcfg.get("actor_topology_feature_dim", mcfg.get("topology_feature_dim", ACTOR_TOPO_FEATURE_DIM))),
            map_topology_feature_dim=int(mcfg.get("map_topology_feature_dim", MAP_TOPO_FEATURE_DIM)),
            num_topology_agents=int(mcfg.get("num_topology_agents", cfg.get("max_agents", 16))),
            num_topology_map=int(mcfg.get("num_topology_map", 64)),
            num_topo=int(mcfg.get("num_topo", 16)),
            mlp_hidden=int(mcfg.get("mlp_hidden", 128)),
            mlp_layers=int(mcfg.get("mlp_layers", 3)),
        )
    return WayformerRouteBC(
        **common,
        mlp_hidden=int(mcfg.get("mlp_hidden", 128)),
        mlp_layers=int(mcfg.get("mlp_layers", 4)),
        num_latents=int(mcfg.get("num_latents", 16)),
    )
