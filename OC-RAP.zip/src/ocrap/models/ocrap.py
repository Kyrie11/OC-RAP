from __future__ import annotations

import torch
from torch import nn

from .encoders import FlatFeatureLayout, MLPEncoder, StructuredTokenEncoder


class OCRAPModel(nn.Module):
    """Neural OC-RAP model with a learned root-query decoder.

    The previous implementation predicted all roots from one global scene
    embedding.  That was useful as a compact smoke model but did not match the
    paper's pipeline, where learned root queries cross-attend to scene-prefix
    tokens and each root obtains its own observation embedding and recovery
    margins.  This module keeps the MLP fallback, but the default structured
    path now implements the paper-aligned decoder:

    scene/prefix tokens -> K learned root queries -> root probabilities,
    post-prefix observation embeddings, recovery signatures, and per-option
    margins conditioned on recovery-option embeddings.
    """

    def __init__(
        self,
        input_dim: int,
        num_roots: int = 8,
        num_options: int = 24,
        d_model: int = 128,
        d_obs: int = 64,
        tau_obs: float = 1.0,
        encoder_type: str = "mlp",
        feature_layout: dict | None = None,
        num_layers: int = 2,
        num_heads: int = 4,
        dropout: float = 0.1,
        d_signature: int = 0,
        d_future_signature: int = 0,
        option_feature_dim: int = 0,
        direct_recovery_value_head: bool = False,
        direct_recovery_value_pooling: str = "scene",
        direct_recovery_value_output: str = "probability",
        direct_recovery_value_regime_conditioning: bool = False,
        direct_recovery_value_num_regimes: int = 4,
        direct_recovery_value_regime_dim: int = 16,
        direct_recovery_opportunity_head: bool = False,
        direct_recovery_value_experts: bool = False,
        direct_recovery_value_num_experts: int = 2,
        direct_recovery_value_expert_routing: str = "bucket",
        direct_recovery_value_router_temperature: float = 1.0,
        direct_recovery_value_router_pooling: str = "candidate",
    ):
        super().__init__()
        self.num_roots = int(num_roots)
        self.num_options = int(num_options)
        self.d_obs = int(d_obs)
        self.tau_obs = float(max(tau_obs, 1e-6))
        self.encoder_type = str(encoder_type)
        self.feature_layout = feature_layout or {}
        self.d_model = int(d_model)
        self.d_signature = int(d_signature)
        self.d_future_signature = int(d_future_signature)
        self.option_feature_dim = int(option_feature_dim)
        self.direct_recovery_value_head = bool(direct_recovery_value_head)
        self.direct_recovery_value_pooling = str(direct_recovery_value_pooling or "scene").strip().lower()
        self.direct_recovery_value_output = str(direct_recovery_value_output or "probability").strip().lower()
        self.direct_recovery_value_regime_conditioning = bool(direct_recovery_value_regime_conditioning)
        self.direct_recovery_value_num_regimes = max(1, int(direct_recovery_value_num_regimes))
        self.direct_recovery_value_regime_dim = max(1, int(direct_recovery_value_regime_dim))
        self.direct_recovery_opportunity_head = bool(direct_recovery_opportunity_head)
        self.direct_recovery_value_experts = bool(direct_recovery_value_experts)
        self.direct_recovery_value_num_experts = max(1, int(direct_recovery_value_num_experts))
        self.direct_recovery_value_expert_routing = str(
            direct_recovery_value_expert_routing or "bucket"
        ).strip().lower()
        self.direct_recovery_value_router_temperature = float(
            max(direct_recovery_value_router_temperature, 1.0e-3)
        )
        self.direct_recovery_value_router_pooling = str(
            direct_recovery_value_router_pooling or "candidate"
        ).strip().lower()
        if self.direct_recovery_value_expert_routing not in {
            "bucket",
            "hard_bucket",
            "soft_observation",
            "soft",
            "moe",
            "uniform",
        }:
            raise ValueError(
                "Unsupported direct_recovery_value_expert_routing="
                f"{direct_recovery_value_expert_routing!r}"
            )
        if self.direct_recovery_value_output not in {"probability", "score"}:
            raise ValueError(f"Unsupported direct_recovery_value_output={direct_recovery_value_output!r}")
        if self.direct_recovery_value_router_pooling not in {"candidate", "scene", "shared_raw"}:
            raise ValueError(
                "Unsupported direct_recovery_value_router_pooling="
                f"{direct_recovery_value_router_pooling!r}"
            )

        if self.encoder_type == "structured_transformer":
            layout = FlatFeatureLayout(**self.feature_layout)
            self.encoder = StructuredTokenEncoder(
                layout=layout,
                d_model=d_model,
                num_layers=num_layers,
                num_heads=num_heads,
                dropout=dropout,
            )
        else:
            self.encoder = MLPEncoder(input_dim, d_model)

        # Root-query decoder: K learned latent root slots attend to the encoded
        # scene-prefix tokens.  For the MLP fallback, the single global embedding
        # is treated as a one-token memory.
        self.root_queries = nn.Parameter(torch.randn(1, self.num_roots, d_model) * 0.02)
        self.root_cross_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        self.root_self_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        self.root_norm1 = nn.LayerNorm(d_model)
        self.root_norm2 = nn.LayerNorm(d_model)
        self.root_ffn = nn.Sequential(
            nn.Linear(d_model, 4 * d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(4 * d_model, d_model),
        )
        self.root_norm3 = nn.LayerNorm(d_model)

        self.option_embeddings = nn.Parameter(torch.randn(1, 1, self.num_options, d_model) * 0.02)
        self.option_feature_proj = (
            nn.Sequential(nn.Linear(self.option_feature_dim, d_model), nn.GELU(), nn.Linear(d_model, d_model))
            if self.option_feature_dim > 0
            else None
        )
        self.root_logit_head = nn.Linear(d_model, 1)
        self.margin_head = nn.Sequential(
            nn.Linear(2 * d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 1),
        )
        self.obs_embed_head = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, self.d_obs))
        self.utility_head = nn.Linear(d_model, 1)
        # v40 OC-UVRA: decouple the calibrated OC-MERO certificate from the
        # candidate preference signal.  The head predicts a bounded deployable
        # recovery value and aleatoric log-variance for each executable prefix.
        # This avoids forcing R_dep, DRS, and the oracle gap to absorb a separate
        # counterfactual ranking objective.
        # v41 OC-CAVA: the v40 head consumed only the frozen CLS token.  The
        # measured validation loss stayed close to a uniform candidate ranking,
        # which means the frozen v39 CLS representation discarded much of the
        # prefix-specific signal needed for counterfactual action comparison.
        # ``candidate_concat`` exposes the encoded ego/prefix/macro/state/control
        # tokens to a small trainable adapter without changing any OC-MERO head.
        direct_in_dim = d_model
        self.direct_candidate_raw_dim = 0
        self.direct_candidate_feature_dim = 0
        if self.encoder_type == "structured_transformer":
            layout = FlatFeatureLayout(**self.feature_layout)
            self.direct_candidate_feature_dim = int(
                layout.ego_dim + layout.prefix_param_dim + layout.num_macros + layout.scalar_dim
                + layout.prefix_flat_dim + layout.control_flat_dim
            )
        if self.direct_recovery_value_pooling in {"candidate_concat", "prefix_concat", "action_concat"}:
            direct_in_dim = 6 * d_model
        elif self.direct_recovery_value_pooling in {"candidate_concat_raw", "action_concat_raw", "certificate_action_adapter"}:
            # Certificate-preserving dual pathway: keep the frozen contextual
            # OC-MERO tokens, but expose raw ego/prefix/macro/state/control
            # blocks to the trainable action-value adapter.  This prevents a
            # frozen certificate encoder from discarding counterfactual action
            # differences while leaving all calibrated certificate heads intact.
            if self.encoder_type != "structured_transformer":
                raise ValueError("candidate_concat_raw requires structured_transformer")
            self.direct_candidate_raw_dim = self.direct_candidate_feature_dim
            direct_in_dim = 6 * d_model + self.direct_candidate_raw_dim
        # Optional regime embedding retained only for controlled ablations. The
        # v44 OC-RAVA default disables it: deployment uses one observation-only
        # value/opportunity model and never receives the evaluation bucket as a
        # neural input. Bucket ids remain available solely to separate training
        # groups and to support an explicit leakage ablation if needed.
        self.direct_regime_embedding = (
            nn.Embedding(self.direct_recovery_value_num_regimes, self.direct_recovery_value_regime_dim)
            if self.direct_recovery_value_head and self.direct_recovery_value_regime_conditioning
            else None
        )
        if self.direct_recovery_value_router_pooling == "scene":
            direct_router_in_dim = d_model
        elif self.direct_recovery_value_router_pooling == "shared_raw":
            if self.encoder_type != "structured_transformer" or self.direct_candidate_feature_dim <= 0:
                raise ValueError("shared_raw router pooling requires structured_transformer")
            direct_router_in_dim = int(input_dim) - self.direct_candidate_feature_dim
            if direct_router_in_dim <= 0:
                raise ValueError("shared_raw router pooling produced an empty observation feature")
        else:
            direct_router_in_dim = direct_in_dim
        if self.direct_regime_embedding is not None:
            direct_in_dim += self.direct_recovery_value_regime_dim
        direct_out_dim = 3 if self.direct_recovery_opportunity_head else 2

        def _make_direct_head() -> nn.Sequential:
            return nn.Sequential(
                nn.LayerNorm(direct_in_dim),
                nn.Linear(direct_in_dim, d_model),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(d_model, d_model // 2),
                nn.GELU(),
                nn.Linear(d_model // 2, direct_out_dim),
            )

        # v45 OC-RAVE: Near-contact and Contact share the observation encoder but
        # use lightweight task experts.  The two datasets may contain the same
        # current observation with different pressure-future teachers, so one
        # unconditional head can receive contradictory labels even after groups
        # are separated.  In soft-observation mode every expert is evaluated and
        # continuously fused from observable scene/prefix features; dataset
        # buckets remain available only for loss stratification/calibration and
        # for the explicit legacy hard-routing ablation.  Safe does not use the
        # direct branch.
        self.direct_value_heads = (
            nn.ModuleList([_make_direct_head() for _ in range(self.direct_recovery_value_num_experts)])
            if self.direct_recovery_value_head and self.direct_recovery_value_experts
            else None
        )
        self.direct_value_head = (
            _make_direct_head()
            if self.direct_recovery_value_head and not self.direct_recovery_value_experts
            else None
        )
        # Observation-conditioned soft routing avoids treating a hand-authored
        # regime id as a policy input.  The router consumes the same observable
        # scene/prefix representation as the experts and produces continuous
        # mixture weights.  Legacy hard bucket routing remains available as an
        # explicit ablation and for loading older checkpoints.
        self.direct_value_router = (
            nn.Sequential(
                nn.LayerNorm(direct_router_in_dim),
                nn.Linear(direct_router_in_dim, max(16, d_model // 2)),
                nn.GELU(),
                nn.Linear(max(16, d_model // 2), self.direct_recovery_value_num_experts),
            )
            if self.direct_value_heads is not None
            and self.direct_recovery_value_expert_routing in {"soft_observation", "soft", "moe"}
            else None
        )
        self.root_signature_head = nn.Linear(d_model, self.d_signature) if self.d_signature > 0 else None
        self.root_future_signature_head = nn.Linear(d_model, self.d_future_signature) if self.d_future_signature > 0 else None

    def _scene_tokens(self, x: torch.Tensor) -> torch.Tensor:
        if self.encoder_type == "structured_transformer" and hasattr(self.encoder, "forward_tokens"):
            return self.encoder.forward_tokens(x)  # type: ignore[attr-defined]
        h = self.encoder(x)
        return h.unsqueeze(1)

    def _decode_roots(self, memory: torch.Tensor) -> torch.Tensor:
        B = memory.shape[0]
        q0 = self.root_queries.expand(B, -1, -1)
        q, _ = self.root_cross_attn(q0, memory, memory, need_weights=False)
        q = self.root_norm1(q0 + q)
        qs, _ = self.root_self_attn(q, q, q, need_weights=False)
        q = self.root_norm2(q + qs)
        q = self.root_norm3(q + self.root_ffn(q))
        return q

    def _option_tokens(self, x: torch.Tensor, option_features: torch.Tensor | None) -> torch.Tensor:
        learned = self.option_embeddings.expand(x.shape[0], self.num_roots, -1, -1)
        if option_features is None or self.option_feature_proj is None:
            return learned
        opt_feat = option_features.to(dtype=x.dtype, device=x.device)
        if opt_feat.dim() == 2:
            opt_feat = opt_feat.unsqueeze(0).expand(x.shape[0], -1, -1)
        if opt_feat.shape[1] != self.num_options:
            # Keep inference robust when an older checkpoint/sample has a shorter
            # option list: pad or truncate to the checkpoint geometry.
            fixed = torch.zeros((opt_feat.shape[0], self.num_options, opt_feat.shape[-1]), dtype=opt_feat.dtype, device=opt_feat.device)
            n = min(self.num_options, opt_feat.shape[1])
            fixed[:, :n] = opt_feat[:, :n]
            opt_feat = fixed
        semantic = self.option_feature_proj(opt_feat).unsqueeze(1).expand(-1, self.num_roots, -1, -1)
        return learned + semantic

    def _candidate_raw_features(self, x: torch.Tensor) -> torch.Tensor:
        """Return raw candidate-conditioned blocks used only by the value adapter."""
        if self.direct_candidate_raw_dim <= 0:
            return x[:, :0]
        # FlatFeatureLayout places ego, prefix parameters, macro/scalars, prefix
        # states and controls first, so the candidate-conditioned slice is
        # contiguous and does not include future/audit labels.
        return x[:, : self.direct_candidate_raw_dim]

    def forward(
        self,
        x: torch.Tensor,
        option_features: torch.Tensor | None = None,
        bucket_id: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        memory = self._scene_tokens(x)
        scene_token = memory[:, 0]
        root_tokens = self._decode_roots(memory)

        root_logits = self.root_logit_head(root_tokens).squeeze(-1)
        obs_embeddings = self.obs_embed_head(root_tokens)

        root_expand = root_tokens.unsqueeze(2).expand(-1, -1, self.num_options, -1)
        opt_expand = self._option_tokens(x, option_features)
        margins = self.margin_head(torch.cat([root_expand, opt_expand], dim=-1)).squeeze(-1)

        diff = obs_embeddings.unsqueeze(2) - obs_embeddings.unsqueeze(1)
        dist2 = (diff * diff).mean(dim=-1)
        C = torch.exp(-dist2 / self.tau_obs).clamp(0.0, 1.0)
        eye = torch.eye(self.num_roots, dtype=C.dtype, device=C.device).unsqueeze(0)
        C = C * (1 - eye) + eye

        out: dict[str, torch.Tensor] = {
            "root_logits": root_logits,
            "margins": margins,
            "obs_embeddings": obs_embeddings,
            "c_star": C,
            "utility": self.utility_head(scene_token).squeeze(-1),
        }
        if self.direct_value_head is not None or self.direct_value_heads is not None:
            direct_features = scene_token
            if self.direct_recovery_value_pooling in {"candidate_concat", "prefix_concat", "action_concat", "candidate_concat_raw", "action_concat_raw", "certificate_action_adapter"}:
                # Token order from StructuredTokenEncoder is
                # [CLS, ego, prefix_param, macro+scalar, prefix_state, control, ...].
                # For the MLP fallback, repeat the only token to retain geometry.
                if memory.shape[1] >= 6:
                    direct_features = torch.cat([memory[:, i] for i in range(6)], dim=-1)
                else:
                    direct_features = scene_token.repeat(1, 6)
                if self.direct_recovery_value_pooling in {"candidate_concat_raw", "action_concat_raw", "certificate_action_adapter"}:
                    direct_features = torch.cat([direct_features, self._candidate_raw_features(x)], dim=-1)
            # v46 OC-RACE can route from the raw shared observation block. This
            # excludes prefix parameters, macro identity, planned states and
            # controls, so every candidate from one scene-time receives the same
            # expert mixture. The legacy candidate-conditioned router remains an
            # explicit ablation for older checkpoints.
            if self.direct_recovery_value_router_pooling == "shared_raw":
                router_features = x[:, self.direct_candidate_feature_dim:]
            elif self.direct_recovery_value_router_pooling == "scene":
                router_features = scene_token
            else:
                router_features = direct_features
            if self.direct_regime_embedding is not None:
                if bucket_id is None:
                    # "other" is the backward-compatible fallback. v44 runtime
                    # code supplies the active regime explicitly for stress runs.
                    bucket_id = torch.full(
                        (x.shape[0],),
                        min(3, self.direct_recovery_value_num_regimes - 1),
                        dtype=torch.long,
                        device=x.device,
                    )
                regime_id = bucket_id.to(device=x.device, dtype=torch.long).reshape(-1)
                regime_id = regime_id.clamp(0, self.direct_recovery_value_num_regimes - 1)
                direct_features = torch.cat([direct_features, self.direct_regime_embedding(regime_id)], dim=-1)
            if self.direct_value_heads is not None:
                all_direct = torch.stack([head(direct_features) for head in self.direct_value_heads], dim=1)
                routing = self.direct_recovery_value_expert_routing
                if routing in {"bucket", "hard_bucket"}:
                    # Backward-compatible ablation: bucket ids safe=0, near=1,
                    # contact=2, other=3; near maps to expert 0 and contact to 1.
                    if bucket_id is None:
                        bucket_id = torch.ones((x.shape[0],), dtype=torch.long, device=x.device)
                    expert_idx = (bucket_id.to(device=x.device, dtype=torch.long).reshape(-1) - 1)
                    expert_idx = expert_idx.clamp(0, self.direct_recovery_value_num_experts - 1)
                    weights = torch.nn.functional.one_hot(
                        expert_idx, num_classes=self.direct_recovery_value_num_experts
                    ).to(dtype=all_direct.dtype)
                elif routing == "uniform":
                    weights = torch.full(
                        (x.shape[0], self.direct_recovery_value_num_experts),
                        1.0 / float(self.direct_recovery_value_num_experts),
                        dtype=all_direct.dtype,
                        device=x.device,
                    )
                else:
                    if self.direct_value_router is None:
                        raise RuntimeError("soft expert routing configured without a router")
                    router_logits = self.direct_value_router(router_features)
                    weights = torch.softmax(
                        router_logits / self.direct_recovery_value_router_temperature, dim=-1
                    )
                    out["direct_expert_logits"] = router_logits
                direct = (all_direct * weights.unsqueeze(-1)).sum(dim=1)
                out["direct_expert_weights"] = weights
                out["direct_expert_outputs"] = all_direct
            elif self.direct_value_head is not None:
                direct = self.direct_value_head(direct_features)
            else:
                raise RuntimeError("direct recovery branch configured without a head")
            out["direct_recovery_value_logit"] = direct[:, 0]
            out["direct_recovery_value_logvar"] = direct[:, 1].clamp(-7.0, 2.0)
            if self.direct_recovery_opportunity_head:
                out["direct_recovery_opportunity_logit"] = direct[:, 2]
        if self.root_signature_head is not None:
            out["root_signature"] = self.root_signature_head(root_tokens)
        if self.root_future_signature_head is not None:
            out["root_future_signature"] = self.root_future_signature_head(root_tokens)
        return out
