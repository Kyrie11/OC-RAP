from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SelectionResult:
    selected_index: int
    reason: str
    admitted: np.ndarray


def crisp_select(utility: np.ndarray, r_dep: np.ndarray, hard: np.ndarray, harm: np.ndarray, feasible: np.ndarray, gamma_rec: float = 0.0, gamma_H: float = 0.0, gamma_D: float = 0.0, nominal_index: int = 0) -> SelectionResult:
    utility = np.asarray(utility, dtype=float)
    r_dep = np.asarray(r_dep, dtype=float)
    hard = np.asarray(hard, dtype=float)
    harm = np.asarray(harm, dtype=float)
    feasible = np.asarray(feasible, dtype=bool)
    admitted = feasible & (r_dep >= gamma_rec) & (hard <= gamma_H) & (harm <= gamma_D)
    if 0 <= nominal_index < len(utility) and admitted[nominal_index]:
        return SelectionResult(int(nominal_index), "nominal_admitted", admitted)
    if admitted.any():
        idxs = np.where(admitted)[0]
        best = int(idxs[np.argmax(utility[idxs])])
        return SelectionResult(best, "best_admitted_utility", admitted)
    # Lexicographic fallback: minimize hard violation, then harm, then maximize r_dep, then utility.
    order = sorted(range(len(utility)), key=lambda i: (not feasible[i], hard[i], harm[i], -r_dep[i], -utility[i]))
    return SelectionResult(int(order[0]), "lexicographic_fallback", admitted)

def _as_1d_float(x: np.ndarray | None, n: int, default: float = 0.0) -> np.ndarray:
    if x is None:
        return np.full((n,), float(default), dtype=float)
    arr = np.asarray(x, dtype=float).reshape(-1)
    if arr.size < n:
        arr = np.pad(arr, (0, n - arr.size), constant_values=float(default))
    return np.where(np.isfinite(arr[:n]), arr[:n], float(default))


def constrained_lcb_select(
    utility: np.ndarray,
    r_dep: np.ndarray,
    hard: np.ndarray,
    harm: np.ndarray,
    feasible: np.ndarray,
    gamma_rec: float = 0.0,
    gamma_H: float = 0.0,
    gamma_D: float = 0.0,
    nominal_index: int = 0,
    *,
    pred_gap: np.ndarray | None = None,
    nominal_deviation: np.ndarray | None = None,
    lcb_beta: float = 0.0,
    nominal_slack: float = 0.0,
    nominal_slack_gap_limit: float = 0.5,
    intervention_penalty: float = 0.03,
    deviation_penalty: float = 0.15,
    recovery_bonus: float = 0.02,
    fallback_rec_weight: float = 0.10,
    fallback_lcb_margin: float = 0.05,
    fallback_gap_margin: float = 0.25,
    nominal_fallback_lcb_slack: float = 0.05,
) -> SelectionResult:
    """Calibrated constrained selector used by OC-RAP in closed loop.

    It uses a conservative recovery lower-bound proxy
    ``r_lcb = r_dep - beta * max(0, oracle_deployable_gap)`` and adds
    explicit intervention/deviation costs so OC-RAP does not over-intervene when
    the nominal prefix is only slightly below the calibrated threshold.
    """
    utility = np.asarray(utility, dtype=float).reshape(-1)
    n = int(utility.size)
    r_dep = _as_1d_float(r_dep, n, default=-np.inf)
    hard = _as_1d_float(hard, n, default=np.inf)
    harm = _as_1d_float(harm, n, default=np.inf)
    feasible = np.asarray(feasible, dtype=bool).reshape(-1)
    if feasible.size < n:
        feasible = np.pad(feasible, (0, n - feasible.size), constant_values=False)
    feasible = feasible[:n]
    gap = np.maximum(0.0, _as_1d_float(pred_gap, n, default=0.0))
    dev = np.maximum(0.0, _as_1d_float(nominal_deviation, n, default=0.0))
    rec_lcb = r_dep - float(lcb_beta) * gap
    safe = feasible & (hard <= float(gamma_H)) & (harm <= float(gamma_D))
    admitted = safe & (rec_lcb >= float(gamma_rec))
    idxs = np.arange(n)
    intervention = (idxs != int(nominal_index)).astype(float)
    score = utility - float(intervention_penalty) * intervention - float(deviation_penalty) * dev + float(recovery_bonus) * (rec_lcb - float(gamma_rec))
    if 0 <= nominal_index < n and safe[nominal_index]:
        nom_margin = rec_lcb[nominal_index] - float(gamma_rec)
        nom_gap = gap[nominal_index]
        if admitted[nominal_index]:
            return SelectionResult(int(nominal_index), "nominal_lcb_admitted", admitted)
        if nom_margin >= -float(nominal_slack) and nom_gap <= float(nominal_slack_gap_limit):
            admitted = admitted.copy()
            admitted[nominal_index] = True
            return SelectionResult(int(nominal_index), "nominal_slack_lcb_admitted", admitted)
    if admitted.any():
        cand = np.where(admitted)[0]
        return SelectionResult(int(cand[np.argmax(score[cand])]), "best_admitted_lcb_score", admitted)
    # No candidate satisfies the calibrated recovery constraint.  This branch is
    # deliberately recovery-first.  Earlier versions used a utility-dominated
    # soft fallback, which could pick high-utility prefixes with lower predicted
    # deployable recoverability and larger oracle--deployable gap.  That defeats
    # the purpose of OC-RAP exactly in low-headroom regimes.  We therefore:
    #   1. keep hard/harm safety as the first gate;
    #   2. restrict fallback candidates to the near-best recovery LCB set;
    #   3. within that set, reject candidates with much larger predicted gap;
    #   4. use utility/intervention/deviation only as a final tie-breaker.
    if safe.any():
        fallback_pool = safe.copy()
    elif feasible.any():
        cand = np.where(feasible)[0]
        min_hard = float(np.min(hard[cand]))
        near_hard = feasible & (hard <= min_hard + 1e-6)
        cand2 = np.where(near_hard)[0]
        min_harm = float(np.min(harm[cand2])) if cand2.size else float(np.min(harm[cand]))
        fallback_pool = near_hard & (harm <= min_harm + 1e-6)
    else:
        fallback_pool = np.ones((n,), dtype=bool)

    cand = np.where(fallback_pool)[0]
    if cand.size == 0:
        cand = np.arange(n)
    best_lcb = float(np.max(rec_lcb[cand])) if cand.size else -np.inf

    if 0 <= nominal_index < n and fallback_pool[nominal_index]:
        nom_lcb = float(rec_lcb[nominal_index])
        nom_gap = float(gap[nominal_index])
        best_gap = float(np.min(gap[cand])) if cand.size else nom_gap
        if nom_lcb >= best_lcb - float(nominal_fallback_lcb_slack) and nom_gap <= best_gap + float(fallback_gap_margin):
            return SelectionResult(int(nominal_index), "nominal_recovery_guarded_fallback", admitted)

    near_best_lcb = fallback_pool & (rec_lcb >= best_lcb - float(fallback_lcb_margin))
    cand = np.where(near_best_lcb)[0]
    if cand.size:
        best_gap = float(np.min(gap[cand]))
        gap_guarded = near_best_lcb & (gap <= best_gap + float(fallback_gap_margin))
        if gap_guarded.any():
            cand = np.where(gap_guarded)[0]
    else:
        cand = np.where(fallback_pool)[0]

    rec_shortfall = np.maximum(0.0, float(gamma_rec) - rec_lcb)
    fallback_score = score - float(fallback_rec_weight) * rec_shortfall - 10.0 * np.maximum(0.0, hard - float(gamma_H)) - 2.0 * np.maximum(0.0, harm - float(gamma_D))
    return SelectionResult(int(cand[np.argmax(fallback_score[cand])]) if cand.size else 0, "recovery_guarded_fallback", admitted)


def calibrated_constrained_select(
    utility: np.ndarray,
    r_dep: np.ndarray,
    hard: np.ndarray,
    harm: np.ndarray,
    feasible: np.ndarray,
    gamma_rec: float = 0.0,
    gamma_H: float = 0.0,
    gamma_D: float = 0.0,
    nominal_index: int = 0,
    *,
    pred_gap: np.ndarray | None = None,
    nominal_deviation: np.ndarray | None = None,
    lcb_beta: float = 0.10,
    shortfall_penalty: float = 1.0,
    gap_penalty: float = 0.05,
    intervention_penalty: float = 0.03,
    deviation_penalty: float = 0.15,
    recovery_bonus: float = 0.02,
    admission_bonus: float = 0.02,
    nominal_slack: float = 0.03,
    nominal_slack_gap_limit: float = 0.50,
    nominal_utility_slack: float = 0.05,
    safe_nominal_slack: float = 0.12,
    regime_name: str | None = None,
    intervention_budget_rate: float | None = None,
    intervention_budget_used: float | None = None,
    intervention_budget_steps: float | None = None,
    intervention_budget_penalty: float = 0.25,
    prefer_admitted: bool = False,
    switch_score_margin: float = 0.0,
    safe_switch_score_margin: float = 0.10,
    safe_min_rec_lcb_gain: float = 0.05,
    safe_min_gap_reduction: float = 0.15,
    budget_preserve_nominal: bool = True,
    budget_nominal_slack: float = 0.08,
    pred_drs: np.ndarray | None = None,
    deployability_bonus: float = 0.0,
    contact_deployability_bonus: float = 0.0,
    contact_gap_penalty: float = 0.0,
    safe_hard_nominal_guard: bool = True,
    safe_nominal_max_gap: float = 0.20,
    safe_override_require_both: bool = True,
    safe_min_drs_gain: float = 0.10,
    safe_force_nominal_when_feasible: bool = False,
    safe_force_nominal_mode: str = "feasible",
    stress_preserve_nominal_min_drs_drop: float = -1.0,
    require_admitted_intervention: bool = False,
    unadmitted_fallback_to_nominal: bool = True,
    intervention_min_pred_drs: float = -1.0,
    intervention_max_pred_gap: float = -1.0,
    safe_cert_min_pred_drs: float = 0.95,
    safe_cert_max_pred_gap: float = 0.20,
    safe_cert_rec_slack: float = 0.15,
    stress_nominal_anchor: bool = False,
    stress_anchor_drs_floor: float = 0.90,
    stress_anchor_max_gap: float = 0.30,
    stress_anchor_rec_slack: float = 0.10,
    stress_anchor_min_drs_gain: float = 0.06,
    stress_anchor_min_rec_gain: float = 0.08,
    stress_anchor_min_gap_reduction: float = 0.05,
    require_intervention_evidence: bool = False,
    intervention_min_rec_lcb_gain: float = 0.00,
    intervention_min_drs_gain: float = 0.00,
    intervention_min_gap_reduction: float = 0.00,
    option_drs_certificate: bool = False,
    option_drs_certificate_threshold: float = 1.01,
    option_drs_certificate_max_gap: float = -1.0,
    option_drs_certificate_rec_slack: float = 0.0,
    option_drs_certificate_min_rec_lcb: float = -1.0e9,
    option_drs_certificate_counts_as_evidence: bool = True,
    relative_recovery_certificate: bool = False,
    relative_recovery_nominal_rec_lcb_max: float = -1.0e9,
    relative_recovery_nominal_gap_min: float = 1.0e9,
    relative_recovery_nominal_drs_max: float = -1.0,
    relative_recovery_min_rec_gain: float = 0.10,
    relative_recovery_min_drs: float = 0.70,
    relative_recovery_min_drs_gain: float = -1.0,
    relative_recovery_max_gap: float = -1.0,
    relative_recovery_max_gap_increase: float = 0.20,
    relative_recovery_bonus: float = 0.0,
    relative_recovery_counts_as_evidence: bool = True,
) -> SelectionResult:
    """Soft calibrated OC-RAP selector.

    ``constrained_lcb_select`` is deliberately hard-gated: candidates below the
    calibrated recovery threshold all fall into a recovery-first fallback.  That
    is useful for stress tests, but in natural/safe scenes it can over-intervene
    because a candidate that misses gamma by a tiny amount is treated like one
    that misses it by a large amount.  This selector keeps hard/harm feasibility
    as a constraint, then turns recovery-threshold shortfall into a continuous
    penalty.  It also has an optional intervention budget and a stronger
    nominal-preservation rule for safe/background buckets.
    """
    utility = np.asarray(utility, dtype=float).reshape(-1)
    n = int(utility.size)
    if n <= 0:
        return SelectionResult(0, "empty_calibrated_selector", np.zeros((0,), dtype=bool))
    r_dep = _as_1d_float(r_dep, n, default=-np.inf)
    hard = _as_1d_float(hard, n, default=np.inf)
    harm = _as_1d_float(harm, n, default=np.inf)
    feasible = np.asarray(feasible, dtype=bool).reshape(-1)
    if feasible.size < n:
        feasible = np.pad(feasible, (0, n - feasible.size), constant_values=False)
    feasible = feasible[:n]
    gap = np.maximum(0.0, _as_1d_float(pred_gap, n, default=0.0))
    dev = np.maximum(0.0, _as_1d_float(nominal_deviation, n, default=0.0))
    drs_proxy = np.clip(_as_1d_float(pred_drs, n, default=0.0), 0.0, 1.0)

    rec_lcb = r_dep - float(lcb_beta) * gap
    safe = feasible & (hard <= float(gamma_H)) & (harm <= float(gamma_D))
    scalar_admitted = safe & (rec_lcb >= float(gamma_rec))

    # v15 dual certificate.  The scalar OC-MERO LCB can be overly pessimistic
    # under the closed-loop distribution shift observed in v14, while the
    # observation-consistent shared-option head can still identify a deployable
    # recovery option.  A non-nominal prefix may therefore be certified either by
    # the calibrated scalar recovery LCB, or by a directly predicted shared
    # recovery-option success certificate with gap/LCB guards.  This keeps the
    # paper claim intact: interventions still require an observation-consistent
    # deployability certificate; they are no longer blocked solely because the
    # aggregate scalar head is conservative.
    option_certified = np.zeros((n,), dtype=bool)
    if bool(option_drs_certificate):
        option_certified = safe & (drs_proxy >= float(option_drs_certificate_threshold))
        if float(option_drs_certificate_max_gap) >= 0.0:
            option_certified &= gap <= float(option_drs_certificate_max_gap)
        option_certified &= rec_lcb >= float(gamma_rec) - float(option_drs_certificate_rec_slack)
        option_certified &= rec_lcb >= float(option_drs_certificate_min_rec_lcb)

    # v16 relative-recovery certificate.  The v15 result showed that a single
    # absolute scalar/DRS threshold can still abstain throughout contact scenes
    # where nominal is clearly low-headroom but one of the current candidates is
    # relatively better.  This certificate is deliberately counterfactual: it is
    # enabled only in a nominal-opportunity state, and it admits non-nominal
    # prefixes that improve predicted deployable recovery over nominal while
    # satisfying DRS and gap guards.  This keeps the method certifiable without
    # returning to the v13 soft fallback.
    relative_certified = np.zeros((n,), dtype=bool)
    rec_gain_vs_nom = np.zeros((n,), dtype=float)
    drs_gain_vs_nom = np.zeros((n,), dtype=float)
    gap_reduction_vs_nom = np.zeros((n,), dtype=float)
    if bool(relative_recovery_certificate) and 0 <= int(nominal_index) < n:
        ni = int(nominal_index)
        rec_gain_vs_nom = rec_lcb - rec_lcb[ni]
        drs_gain_vs_nom = drs_proxy - drs_proxy[ni]
        gap_reduction_vs_nom = gap[ni] - gap
        nominal_opportunity = (
            rec_lcb[ni] <= float(relative_recovery_nominal_rec_lcb_max)
            or gap[ni] >= float(relative_recovery_nominal_gap_min)
            or (float(relative_recovery_nominal_drs_max) >= 0.0 and drs_proxy[ni] <= float(relative_recovery_nominal_drs_max))
        )
        if bool(nominal_opportunity):
            relative_certified = safe & (rec_gain_vs_nom >= float(relative_recovery_min_rec_gain))
            relative_certified &= drs_proxy >= float(relative_recovery_min_drs)
            if float(relative_recovery_min_drs_gain) >= 0.0:
                relative_certified &= drs_gain_vs_nom >= float(relative_recovery_min_drs_gain)
            if float(relative_recovery_max_gap) >= 0.0:
                relative_certified &= gap <= float(relative_recovery_max_gap)
            if float(relative_recovery_max_gap_increase) >= 0.0:
                relative_certified &= gap <= gap[ni] + float(relative_recovery_max_gap_increase)
            relative_certified[ni] = False

    admitted = scalar_admitted | option_certified | relative_certified
    idxs = np.arange(n)
    intervention = (idxs != int(nominal_index)).astype(float)
    regime = (regime_name or "").lower()
    is_safe_regime = "safe" in regime or "normal" in regime or "background" in regime
    is_contact_regime = "contact" in regime

    # Continuous recovery shortfall; finite guard prevents NaNs from dominating.
    rec_shortfall = np.maximum(0.0, float(gamma_rec) - rec_lcb)
    rec_shortfall = np.where(np.isfinite(rec_shortfall), rec_shortfall, 1.0e6)
    score = (
        utility
        - float(shortfall_penalty) * rec_shortfall
        - float(gap_penalty) * gap
        - float(intervention_penalty) * intervention
        - float(deviation_penalty) * dev
        + float(recovery_bonus) * (rec_lcb - float(gamma_rec))
        + float(admission_bonus) * admitted.astype(float)
        + float(deployability_bonus) * drs_proxy
    )
    if bool(relative_recovery_certificate) and float(relative_recovery_bonus) != 0.0:
        rel_adv = np.maximum(0.0, rec_gain_vs_nom) + 0.25 * np.maximum(0.0, drs_gain_vs_nom) + 0.10 * np.maximum(0.0, gap_reduction_vs_nom)
        score = score + float(relative_recovery_bonus) * rel_adv * relative_certified.astype(float)
    if is_contact_regime:
        score = score + float(contact_deployability_bonus) * drs_proxy - float(contact_gap_penalty) * gap

    # If the current rollout already exceeded the intervention budget, increase
    # the marginal cost of deviating from nominal.  This is intentionally a soft
    # budget because emergency recovery should still be selectable.
    if intervention_budget_rate is not None and intervention_budget_steps not in {None, 0}:
        try:
            used = float(intervention_budget_used or 0.0)
            steps = max(1.0, float(intervention_budget_steps or 1.0))
            target = float(intervention_budget_rate)
            over = max(0.0, (used / steps) - target)
            if over > 0.0:
                score = score - float(intervention_budget_penalty) * over * intervention
        except Exception:
            pass

    if safe.any():
        pool = safe.copy()
    elif feasible.any():
        # Preserve the original hard/harm safety priority when no fully safe
        # candidate exists.
        cand = np.where(feasible)[0]
        min_hard = float(np.min(hard[cand]))
        near_hard = feasible & (hard <= min_hard + 1.0e-6)
        cand2 = np.where(near_hard)[0]
        min_harm = float(np.min(harm[cand2])) if cand2.size else float(np.min(harm[cand]))
        pool = near_hard & (harm <= min_harm + 1.0e-6)
    else:
        pool = np.ones((n,), dtype=bool)

    # Safe/NUP gate.  In benign regimes the paper claim is nominal utility
    # preservation, not recovery maximization.  The learned recovery heads can be
    # pessimistic on safe_v2 because the stress regimes dominate negative
    # deployability.  Therefore, when the nominal prefix is dynamically feasible
    # and the active regime is safe/background, allow an explicit hard lock that
    # bypasses noisy recovery-head shortfall.
    if bool(safe_force_nominal_when_feasible) and is_safe_regime and 0 <= nominal_index < n:
        # In safe/background regimes, nominal preservation should be a certifiable
        # behavior, not just an unconditional heuristic.  `always` keeps the old
        # hard lock for ablation/papercheck; `certified` locks nominal only when
        # the learned heads and feasibility metadata agree that nominal is already
        # deployable and low-gap.
        force_mode = str(safe_force_nominal_mode or "feasible").strip().lower()
        certified = (
            pool[nominal_index]
            and drs_proxy[nominal_index] >= float(safe_cert_min_pred_drs)
            and gap[nominal_index] <= float(safe_cert_max_pred_gap)
            and rec_lcb[nominal_index] >= float(gamma_rec) - float(safe_cert_rec_slack)
        )
        allow_force = (
            force_mode in {"always", "present", "nominal", "hard"}
            or (pool[nominal_index] and force_mode in {"", "feasible", "safe"})
            or (certified and force_mode in {"cert", "certified", "learned", "model", "guarded"})
        )
        if allow_force:
            admitted = admitted.copy()
            admitted[nominal_index] = True
            reason = "nominal_safe_certified_locked" if force_mode in {"cert", "certified", "learned", "model", "guarded"} else "nominal_safe_force_locked"
            return SelectionResult(int(nominal_index), reason, admitted)

    # Stress-regime option: when calibrated-admitted candidates exist, rank only
    # within them.  The default remains soft-constrained for backward
    # compatibility, but near-contact/contact experiments should set
    # prefer_admitted_by_bucket=true so DRS is not sacrificed to high utility.
    rank_pool = pool & admitted if bool(prefer_admitted) and bool((pool & admitted).any()) else pool

    cand = np.where(rank_pool)[0]
    if cand.size == 0:
        cand = np.arange(n)
    best_idx = int(cand[np.argmax(score[cand])])

    # Admitted-intervention abstention.  OC-RAP's claim is deployable recovery,
    # so executing a recovery prefix that the calibrated selector itself did not
    # admit is hard to defend in paper experiments.  When enabled, intervention
    # is allowed only if a candidate passes calibrated admission and optional
    # predicted shared-action DRS/gap guards.  If none is certified, preserve
    # nominal rather than taking a high-utility but uncertified recovery action.
    if bool(require_admitted_intervention):
        certified_intervention = admitted.copy()
        if float(intervention_min_pred_drs) >= 0.0:
            certified_intervention &= drs_proxy >= float(intervention_min_pred_drs)
        if float(intervention_max_pred_gap) >= 0.0:
            certified_intervention &= gap <= float(intervention_max_pred_gap)
        certified_intervention &= pool
        certified_non_nom = certified_intervention.copy()
        if 0 <= nominal_index < n:
            certified_non_nom[int(nominal_index)] = False

        # v14: certified intervention must not merely pass an absolute
        # threshold; it should have some predicted evidence that switching away
        # from nominal improves deployable recoverability or closes the
        # oracle--deployability gap.  This keeps OC-RAP from reducing FRA/ODG by
        # taking low-DRS recovery prefixes and turns abstention into an explicit
        # learned/certified decision.
        if bool(require_intervention_evidence) and 0 <= nominal_index < n:
            rec_gain = rec_lcb - rec_lcb[int(nominal_index)]
            drs_gain = drs_proxy - drs_proxy[int(nominal_index)]
            gap_reduction = gap[int(nominal_index)] - gap
            evidence = (
                (rec_gain >= float(intervention_min_rec_lcb_gain))
                | (drs_gain >= float(intervention_min_drs_gain))
                | (gap_reduction >= float(intervention_min_gap_reduction))
            )
            if bool(option_drs_certificate_counts_as_evidence):
                evidence = evidence | option_certified
            if bool(relative_recovery_counts_as_evidence):
                evidence = evidence | relative_certified
            certified_non_nom &= evidence

        if bool(certified_non_nom.any()):
            cc = np.where(certified_non_nom)[0]
            best_idx = int(cc[np.argmax(score[cc])])
        elif 0 <= nominal_index < n and bool(unadmitted_fallback_to_nominal):
            # Important: do not require nominal to be in the temporary hard/harm
            # pool.  In closed-loop feature-only runs the nominal metadata can
            # be noisy; executing an uncertified recovery is harder to defend
            # than abstaining to nominal.  This fixes the v13 failure where
            # require_admitted_intervention=true still produced
            # best_calibrated_soft_constraint interventions.
            admitted = admitted.copy()
            admitted[int(nominal_index)] = True
            return SelectionResult(int(nominal_index), "nominal_no_certified_intervention_preserved", admitted)
        elif not admitted[best_idx]:
            admitted_pool = np.where(pool & admitted)[0]
            if admitted_pool.size > 0:
                best_idx = int(admitted_pool[np.argmax(score[admitted_pool])])
            elif 0 <= nominal_index < n:
                admitted = admitted.copy()
                admitted[int(nominal_index)] = True
                return SelectionResult(int(nominal_index), "nominal_no_certified_intervention_preserved", admitted)

    # Stress DRS guard.  A recurring failure mode in the current results is that
    # learned OC-RAP lowers FRA/ODG but sacrifices executed DRS.  When configured,
    # do not switch away from a feasible nominal prefix to a candidate whose
    # predicted shared-option success is materially worse than nominal.  Keep the
    # default disabled because early recovery may deliberately trade nominal
    # behavior for safety.
    if (not is_safe_regime) and float(stress_preserve_nominal_min_drs_drop) >= 0.0 and 0 <= nominal_index < n and pool[nominal_index]:
        if drs_proxy[best_idx] + float(stress_preserve_nominal_min_drs_drop) < drs_proxy[nominal_index]:
            admitted = admitted.copy()
            admitted[nominal_index] = True
            return SelectionResult(int(nominal_index), "nominal_stress_drs_guard", admitted)

    # Stress-regime nominal anchor.  Near-contact scenes are still benign until
    # impact, and contact scenes often have a high-quality nominal recovery
    # baseline.  Avoid switching away from a predicted-good nominal prefix unless
    # the learned candidate brings a material deployability/gap advantage.  This
    # is intentionally optional and should be reported as a cautious-selector
    # ablation, not hidden as a universal rule.
    if bool(stress_nominal_anchor) and (not is_safe_regime) and 0 <= nominal_index < n and pool[nominal_index]:
        nominal_anchor_ok = (
            drs_proxy[nominal_index] >= float(stress_anchor_drs_floor)
            and gap[nominal_index] <= float(stress_anchor_max_gap)
            and rec_lcb[nominal_index] >= float(gamma_rec) - float(stress_anchor_rec_slack)
        )
        if nominal_anchor_ok and best_idx != int(nominal_index):
            drs_gain = float(drs_proxy[best_idx] - drs_proxy[nominal_index])
            rec_gain = float(rec_lcb[best_idx] - rec_lcb[nominal_index])
            gap_reduction = float(gap[nominal_index] - gap[best_idx])
            if (
                drs_gain < float(stress_anchor_min_drs_gain)
                and rec_gain < float(stress_anchor_min_rec_gain)
                and gap_reduction < float(stress_anchor_min_gap_reduction)
            ):
                admitted = admitted.copy()
                admitted[nominal_index] = True
                return SelectionResult(int(nominal_index), "nominal_stress_anchor_preserved", admitted)

    # Nominal-preserving calibration.  In safe/background regimes, recovery
    # shortfall by itself should not trigger large behavior changes unless the
    # alternative is clearly better in calibrated score and materially improves
    # deployable-recovery LCB or oracle-deployable gap.
    nominal_extra_slack = float(safe_nominal_slack if is_safe_regime else nominal_slack)
    budget_exceeded = False
    if intervention_budget_rate is not None and intervention_budget_steps not in {None, 0}:
        try:
            budget_exceeded = (float(intervention_budget_used or 0.0) / max(1.0, float(intervention_budget_steps or 1.0))) >= float(intervention_budget_rate)
        except Exception:
            budget_exceeded = False

    if 0 <= nominal_index < n and pool[nominal_index]:
        nom_gap_ok = gap[nominal_index] <= float(nominal_slack_gap_limit)
        nom_near_gamma = rec_lcb[nominal_index] >= float(gamma_rec) - nominal_extra_slack
        nom_near_score = score[nominal_index] >= score[best_idx] - float(nominal_utility_slack)
        if admitted[nominal_index]:
            return SelectionResult(int(nominal_index), "nominal_calibrated_admitted", admitted)
        if bool(budget_preserve_nominal) and budget_exceeded and nom_gap_ok and rec_lcb[nominal_index] >= float(gamma_rec) - float(budget_nominal_slack):
            admitted = admitted.copy()
            admitted[nominal_index] = True
            return SelectionResult(int(nominal_index), "nominal_budget_preserved", admitted)
        if is_safe_regime and nom_gap_ok and nom_near_gamma:
            score_gain = float(score[best_idx] - score[nominal_index])
            rec_gain = float(rec_lcb[best_idx] - rec_lcb[nominal_index])
            gap_reduction = float(gap[nominal_index] - gap[best_idx])
            drs_gain = float(drs_proxy[best_idx] - drs_proxy[nominal_index])
            material_recovery_gain = rec_gain >= float(safe_min_rec_lcb_gain)
            material_gap_gain = gap_reduction >= float(safe_min_gap_reduction)
            material_drs_gain = drs_gain >= float(safe_min_drs_gain)
            if bool(safe_hard_nominal_guard) and gap[nominal_index] <= float(safe_nominal_max_gap):
                # Safe_v2 is the nominal-preservation regime.  Do not switch for
                # a single noisy headroom advantage; require a score improvement
                # plus consistent recovery/gap evidence.
                enough_evidence = (material_recovery_gain and material_gap_gain) if bool(safe_override_require_both) else (material_recovery_gain or material_gap_gain or material_drs_gain)
                if (not enough_evidence) or score_gain < float(safe_switch_score_margin):
                    admitted = admitted.copy()
                    admitted[nominal_index] = True
                    return SelectionResult(int(nominal_index), "nominal_safe_switch_guard", admitted)
            # Safe/background is a nominal-preserving operating region.  Switch
            # away from nominal only when the alternative is not just higher
            # scoring, but meaningfully improves calibrated recoverability or
            # reduces oracle-deployable gap.
            if (not material_recovery_gain and not material_gap_gain and not material_drs_gain) or score_gain < float(safe_switch_score_margin):
                admitted = admitted.copy()
                admitted[nominal_index] = True
                return SelectionResult(int(nominal_index), "nominal_safe_switch_guard", admitted)
        if nom_gap_ok and nom_near_gamma and nom_near_score:
            admitted = admitted.copy()
            admitted[nominal_index] = True
            return SelectionResult(int(nominal_index), "nominal_calibrated_preserved", admitted)
        if (not is_safe_regime) and float(score[best_idx] - score[nominal_index]) < float(switch_score_margin) and nom_gap_ok and nom_near_gamma:
            admitted = admitted.copy()
            admitted[nominal_index] = True
            return SelectionResult(int(nominal_index), "nominal_switch_margin_preserved", admitted)

    reason = "best_calibrated_admitted_score" if admitted[best_idx] else "best_calibrated_soft_constraint"
    if admitted[best_idx] and relative_certified[best_idx] and not scalar_admitted[best_idx] and not option_certified[best_idx]:
        reason = "best_relative_recovery_certified_score"
    elif admitted[best_idx] and option_certified[best_idx] and not scalar_admitted[best_idx]:
        reason = "best_option_drs_certified_score"
    if bool(prefer_admitted) and bool((pool & admitted).any()) and admitted[best_idx]:
        if relative_certified[best_idx] and not scalar_admitted[best_idx] and not option_certified[best_idx]:
            reason = "best_relative_recovery_certified_prefer_admitted"
        elif option_certified[best_idx] and not scalar_admitted[best_idx]:
            reason = "best_option_drs_certified_prefer_admitted"
        else:
            reason = "best_calibrated_prefer_admitted"
    return SelectionResult(best_idx, reason, admitted)

