#!/usr/bin/env bash
set -euo pipefail

export OCRAP_ROOT=${OCRAP_ROOT:-/data0/senzeyu2/dataset/OCRAP}
export TRAIN_MIX=${TRAIN_MIX:-$OCRAP_ROOT/train_safe,$OCRAP_ROOT/train_contact,$OCRAP_ROOT/train_near_contact}
export VAL_MIX=${VAL_MIX:-$OCRAP_ROOT/val_safe,$OCRAP_ROOT/val_contact,$OCRAP_ROOT/val_near_contact}
export RUN=${RUN:-runs/ocrap_v21_macro_calibrated}
export MODEL_DIR=${MODEL_DIR:-$RUN/model_v21}
export CAL_DIR=${CAL_DIR:-$RUN/calibration}
mkdir -p "$MODEL_DIR" "$CAL_DIR"

# v21 trains the model head that v20 implicitly assumed was already reliable:
# macro-conditioned brake/stabilize deployability inside each scene-time group.
PYTHONUNBUFFERED=1 python -u -m ocrap.cli train \
  --dataset "$TRAIN_MIX" \
  --val-dataset "$VAL_MIX" \
  --output "$MODEL_DIR" \
  --set training.epochs=40 \
  --set training.batch_size=64 \
  --set training.lr=0.0003 \
  --set training.weight_decay=0.0001 \
  --set training.artifact_sampler_weight=1.0 \
  --set training.negative_deployable_sampler_weight=1.0 \
  --set training.regime_balance_power=0.50 \
  --set training.group_batching=true \
  --set training.group_batching_replacement=true \
  --set training.num_workers=4 \
  --set training.progress=true \
  --set training.require_cuda=true \
  --set training.save_every_epoch=false \
  --set model.encoder_type=structured_transformer \
  --set model.d_model=192 \
  --set model.d_obs=64 \
  --set model.transformer_layers=2 \
  --set model.transformer_heads=4 \
  --set loss_weights.margin=2.0 \
  --set loss_weights.obs=1.0 \
  --set loss_weights.anti_oracle=1.0 \
  --set loss_weights.utility=0.2 \
  --set loss_weights.option_q=0.60 \
  --set loss_weights.option_admission=0.45 \
  --set loss_weights.option_success=0.35 \
  --set loss_weights.option_success_bce=0.35 \
  --set loss_weights.option_best=0.30 \
  --set loss_weights.group_ce=0.30 \
  --set loss_weights.group_distill=0.20 \
  --set loss_weights.nominal_switch=0.12 \
  --set loss_weights.safe_nominal=0.20 \
  --set loss_weights.protective_macro=0.85 \
  --set training.group_ce_temperature=0.35 \
  --set training.group_ce_teacher_gap_weight=0.25 \
  --set training.group_ce_pred_gap_weight=0.25 \
  --set training.group_distill_teacher_gap_weight=0.25 \
  --set training.group_distill_pred_gap_weight=0.25 \
  --set training.protective_macro_ids=2,7 \
  --set training.protective_macro_bucket_ids=2 \
  --set training.protective_macro_min_teacher_r_dep=0.0 \
  --set training.protective_macro_min_teacher_drs=0.50 \
  --set training.protective_macro_min_teacher_pcd_gain=0.02 \
  --set training.protective_macro_max_nominal_teacher_pcd=0.90 \
  --set training.protective_macro_margin=0.14 \
  --set training.protective_macro_pred_gap_weight=0.18 \
  --set training.protective_macro_pred_drs_weight=0.65 \
  --set training.protective_macro_teacher_gap_weight=0.10 \
  --set training.protective_macro_teacher_drs_weight=0.70 \
  --set training.protective_macro_target_min_pred_drs=0.62 \
  2>&1 | tee "$MODEL_DIR/train_v21.log"

# Mixed calibration is kept for evaluate compatibility; per-bucket calibrations
# produce the gamma map used by the closed-loop selector.
PYTHONUNBUFFERED=1 python -u -m ocrap.cli calibrate \
  --dataset "$VAL_MIX" \
  --checkpoint "$MODEL_DIR/best.pt" \
  --output "$CAL_DIR/calibration_mix_v21.json" \
  --set calibration.required_min_for_delta=100 \
  2>&1 | tee "$CAL_DIR/calibrate_mix_v21.log"

PYTHONUNBUFFERED=1 python -u -m ocrap.cli calibrate \
  --dataset "$OCRAP_ROOT/val_safe" \
  --checkpoint "$MODEL_DIR/best.pt" \
  --output "$CAL_DIR/calibration_safe_v21.json" \
  --set calibration.required_min_for_delta=50 \
  2>&1 | tee "$CAL_DIR/calibrate_safe_v21.log"

PYTHONUNBUFFERED=1 python -u -m ocrap.cli calibrate \
  --dataset "$OCRAP_ROOT/val_near_contact" \
  --checkpoint "$MODEL_DIR/best.pt" \
  --output "$CAL_DIR/calibration_near_v21.json" \
  --set calibration.required_min_for_delta=50 \
  2>&1 | tee "$CAL_DIR/calibrate_near_v21.log"

PYTHONUNBUFFERED=1 python -u -m ocrap.cli calibrate \
  --dataset "$OCRAP_ROOT/val_contact" \
  --checkpoint "$MODEL_DIR/best.pt" \
  --output "$CAL_DIR/calibration_contact_v21.json" \
  --set calibration.required_min_for_delta=50 \
  2>&1 | tee "$CAL_DIR/calibrate_contact_v21.log"

python tools/write_gamma_by_bucket.py \
  --safe "$CAL_DIR/calibration_safe_v21.json" \
  --near "$CAL_DIR/calibration_near_v21.json" \
  --contact "$CAL_DIR/calibration_contact_v21.json" \
  --delta 0.05 \
  --output "$CAL_DIR/gamma_rec_by_bucket_v21.json" \
  2>&1 | tee "$CAL_DIR/write_gamma_v21.log"

printf '\n[v21] model: %s\n[v21] calibration: %s\n[v21] gamma map: %s\n' "$MODEL_DIR/best.pt" "$CAL_DIR/calibration_mix_v21.json" "$CAL_DIR/gamma_rec_by_bucket_v21.json"
