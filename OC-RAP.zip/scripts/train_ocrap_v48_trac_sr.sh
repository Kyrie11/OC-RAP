#!/usr/bin/env bash
set -euo pipefail

REPO="${OCRAP_REPO:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO"
export PYTHONPATH="$REPO/src${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1
# Two concurrent A30 jobs share a Xeon Gold 5220R. Limit intra-op pools so
# dataloader workers do not oversubscribe the CPU.
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-4}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-4}"
export NUMEXPR_NUM_THREADS="${NUMEXPR_NUM_THREADS:-4}"

TRAIN_OCRAP_ROOT="${TRAIN_OCRAP_ROOT:-/data0/senzeyu2/dataset/OCRAP_v48_train}"
EVAL_OCRAP_ROOT="${EVAL_OCRAP_ROOT:-/data0/senzeyu2/dataset/OCRAP}"
TRAIN_MIX="${TRAIN_MIX:-$TRAIN_OCRAP_ROOT/train_near_contact,$TRAIN_OCRAP_ROOT/train_contact}"
VAL_MIX="${VAL_MIX:-$EVAL_OCRAP_ROOT/val_near_contact,$EVAL_OCRAP_ROOT/val_contact}"
CAL_MIX="${CAL_MIX:-$VAL_MIX}"
INIT_CKPT="${INIT_CKPT:-runs/ocrap_v47_trac_balanced/model_v47_trac/best.pt}"
VARIANT="${VARIANT:-balanced}"
RUN="${RUN:-runs/ocrap_v48_trac_sr_${VARIANT}}"
MODEL_DIR="${MODEL_DIR:-$RUN/model_v48_trac_sr}"
CAL_DIR="${CAL_DIR:-$RUN/calibration}"
LOG_DIR="${LOG_DIR:-$RUN/logs}"
TRAIN_GPU="${TRAIN_GPU:-0}"
GROUP_INDEX="${GROUP_INDEX:-$RUN/teacher_pcd_train_index.jsonl}"
mkdir -p "$MODEL_DIR" "$CAL_DIR" "$LOG_DIR"
[[ -f "$INIT_CKPT" ]] || { echo "missing INIT_CKPT=$INIT_CKPT" >&2; exit 2; }
[[ -f "$GROUP_INDEX" ]] || { echo "missing GROUP_INDEX=$GROUP_INDEX" >&2; exit 2; }

case "$VARIANT" in
  balanced)
    LR="${LR:-0.00012}"; ENCODER_LR_SCALE="${ENCODER_LR_SCALE:-0.18}"
    POS_W="${POS_W:-6.0}"; FP_W="${FP_W:-2.2}"; HARM_W="${HARM_W:-2.0}"
    SETWISE_W="${SETWISE_W:-2.0}"; DISAGREE="${DISAGREE:-0.50}" ;;
  precision)
    LR="${LR:-0.00009}"; ENCODER_LR_SCALE="${ENCODER_LR_SCALE:-0.12}"
    POS_W="${POS_W:-5.0}"; FP_W="${FP_W:-3.5}"; HARM_W="${HARM_W:-3.0}"
    SETWISE_W="${SETWISE_W:-2.5}"; DISAGREE="${DISAGREE:-0.70}" ;;
  *) echo "unknown VARIANT=$VARIANT" >&2; exit 2 ;;
esac

# No encoder freeze.  v47's candidate AUC showed learnable signal, but its
# frozen representation could not turn that signal into a correct setwise top-1.
CUDA_VISIBLE_DEVICES="$TRAIN_GPU" python -u -m ocrap.cli train \
  --dataset "$TRAIN_MIX" --val-dataset "$VAL_MIX" --output "$MODEL_DIR" \
  --set training.init_checkpoint="$INIT_CKPT" \
  --set training.freeze_param_prefixes='' \
  --set training.direct_only_fast_path=true \
  --set training.group_index_path="$GROUP_INDEX" \
  --set training.epochs="${EPOCHS:-12}" --set training.early_stop_patience="${PATIENCE:-3}" \
  --set training.batch_size="${BATCH_SIZE:-96}" --set training.lr="$LR" \
  --set training.encoder_lr_scale="$ENCODER_LR_SCALE" --set training.weight_decay=0.00002 \
  --set training.grad_clip=3.0 --set training.require_cuda=true \
  --set training.amp=true --set training.amp_dtype=bfloat16 \
  --set training.allow_tf32=true --set training.matmul_precision=high \
  --set training.cudnn_benchmark=true --set training.pin_memory=true \
  --set training.num_workers="${NUM_WORKERS:-6}" --set training.persistent_workers=true \
  --set training.prefetch_factor="${PREFETCH_FACTOR:-2}" --set training.progress=true \
  --set training.save_every_epoch=false --set training.best_metric=loss_direct_recovery_value_worst \
  --set training.best_metric_mode=min \
  --set training.group_batching=true --set training.group_batching_replacement=true \
  --set training.group_batch_positive_advantage_boost="${POSITIVE_GROUP_BOOST:-5.0}" \
  --set training.group_batch_positive_advantage_gain_min="${POSITIVE_GAIN:-0.015}" \
  --set training.group_batch_positive_advantage_macro_ids=2,3,5,6,7 \
  --set training.group_batch_positive_advantage_bucket_ids=1,2 \
  --set training.group_batch_scene_balance_power="${SCENE_BALANCE_POWER:-0.50}" \
  --set training.group_batch_hard_boost=0 \
  --set training.artifact_sampler_weight=0 --set training.negative_deployable_sampler_weight=0 \
  --set training.safe_positive_sampler_weight=0 --set training.regime_balance_power=1.0 \
  --set model.encoder_type=structured_transformer --set model.d_model=192 --set model.d_obs=64 \
  --set model.transformer_layers=2 --set model.transformer_heads=4 \
  --set model.direct_recovery_value_head=true \
  --set model.direct_recovery_value_pooling=candidate_concat_raw \
  --set model.direct_recovery_value_output=score \
  --set model.direct_recovery_value_regime_conditioning=false \
  --set model.direct_recovery_value_experts=true \
  --set model.direct_recovery_value_num_experts=2 \
  --set model.direct_recovery_value_expert_routing=robust_ensemble \
  --set model.direct_recovery_expert_disagreement_penalty="$DISAGREE" \
  --set model.direct_recovery_opportunity_head=true \
  --set model.direct_recovery_harm_head=true \
  --set loss_weights.dep=0 --set loss_weights.orc=0 --set loss_weights.assign=0 \
  --set loss_weights.sig=0 --set loss_weights.margin=0 --set loss_weights.obs=0 \
  --set loss_weights.anti_oracle=0 --set loss_weights.artifact_gap=0 \
  --set loss_weights.admission=0 --set loss_weights.utility=0 \
  --set loss_weights.option_q=0 --set loss_weights.option_admission=0 \
  --set loss_weights.option_success=0 --set loss_weights.option_success_bce=0 \
  --set loss_weights.option_best=0 --set loss_weights.group_ce=0 \
  --set loss_weights.group_distill=0 --set loss_weights.nominal_switch=0 \
  --set loss_weights.safe_nominal=0 --set loss_weights.protective_macro=0 \
  --set loss_weights.macro_drs=0 --set loss_weights.teacher_pcd_direct=0 \
  --set loss_weights.recovery_advantage=0 --set loss_weights.direct_router_balance=0 \
  --set loss_weights.direct_recovery_value="${DIRECT_VALUE_WEIGHT:-10.0}" \
  --set training.direct_value_macro_ids=2,3,5,6,7 --set training.direct_value_bucket_ids=1,2 \
  --set training.direct_value_temperature="${DIRECT_TEMPERATURE:-0.10}" \
  --set training.direct_value_positive_gain="${POSITIVE_GAIN:-0.015}" \
  --set training.direct_value_negative_gain="${NEGATIVE_GAIN:-0.010}" \
  --set training.direct_value_rank_margin="${RANK_MARGIN:-0.020}" \
  --set training.direct_value_point_weight=0.05 \
  --set training.direct_value_listwise_weight=0.15 \
  --set training.direct_value_centered_weight=1.0 \
  --set training.direct_value_advantage_weight=1.0 \
  --set training.direct_value_output_mode=score \
  --set training.direct_value_pairwise_weight=1.5 \
  --set training.direct_value_top_rank_weight=1.5 \
  --set training.direct_value_positive_group_weight="$POS_W" \
  --set training.direct_value_negative_group_weight=1.5 \
  --set training.direct_value_ambiguous_group_weight=0.08 \
  --set training.direct_value_near_weight=1.4 \
  --set training.direct_value_contact_weight=1.6 \
  --set training.direct_value_min_group_range=0.004 \
  --set training.direct_value_false_positive_weight="$FP_W" \
  --set training.direct_value_opportunity_weight=1.5 \
  --set training.direct_value_opportunity_pos_weight=8.0 \
  --set training.direct_value_harm_weight="$HARM_W" \
  --set training.direct_value_harm_pos_weight=7.0 \
  --set training.direct_value_setwise_admission_weight="$SETWISE_W" \
  --set training.direct_value_opportunity_admission_weight=0.50 \
  --set training.direct_value_harm_admission_weight=1.00 \
  --set training.direct_value_expert_specialization_weight=0.40 \
  2>&1 | tee "$LOG_DIR/train_v48_trac_sr.log"

# Standard OC-MERO calibration is retained for the base feasibility certificate.
for bucket in mix safe near contact; do
  case "$bucket" in
    mix) data="$CAL_MIX"; min=100 ;;
    safe) data="${VAL_SAFE:-$EVAL_OCRAP_ROOT/val_safe}"; min=50 ;;
    near) data="${VAL_NEAR:-$EVAL_OCRAP_ROOT/val_near_contact}"; min=50 ;;
    contact) data="${VAL_CONTACT:-$EVAL_OCRAP_ROOT/val_contact}"; min=50 ;;
  esac
  CUDA_VISIBLE_DEVICES="$TRAIN_GPU" python -u -m ocrap.cli calibrate \
    --dataset "$data" --checkpoint "$MODEL_DIR/best.pt" \
    --output "$CAL_DIR/calibration_${bucket}_v48.json" \
    --set calibration.required_min_for_delta="$min" \
    2>&1 | tee "$LOG_DIR/calibrate_${bucket}_v48.log"
done
python tools/write_gamma_by_bucket.py \
  --safe "$CAL_DIR/calibration_safe_v48.json" \
  --near "$CAL_DIR/calibration_near_v48.json" \
  --contact "$CAL_DIR/calibration_contact_v48.json" \
  --delta 0.05 --output "$CAL_DIR/gamma_rec_by_bucket_v48.json" \
  2>&1 | tee "$LOG_DIR/write_gamma_v48.log"
