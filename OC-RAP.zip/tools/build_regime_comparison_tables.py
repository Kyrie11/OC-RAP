#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

from ocrap.external_baselines.provenance import find_provenance


SCHEMA: dict[str, list[tuple[str, str, str]]] = {
    "safe": [
        ("num_scenes", "Scenes", "count"),
        ("collision_scene_rate", "Collision scene rate ↓", "rate"),
        ("offroad_scene_rate", "Off-road scene rate ↓", "rate"),
        ("minimum_clearance_m", "Minimum clearance [m] ↑", "float"),
        ("scene_min_clearance_m_p05", "Scene clearance p05 [m] ↑", "float"),
        ("scene_min_clearance_m_median", "Scene clearance median [m] ↑", "float"),
        ("minimum_ttc_s", "Minimum TTC [s] ↑", "float"),
        ("scene_ttc_s_p05", "Scene TTC p05 [s] ↑", "float"),
        ("closed_loop_bounded_NUP", "Bounded NUP ↑", "float"),
        ("intervention_rate", "Intervention rate", "rate"),
        ("decision_latency_ms", "Decision latency [ms] ↓", "float"),
    ],
    "near": [
        ("num_scenes", "Scenes", "count"),
        ("collision_scene_rate", "Collision scene rate ↓", "rate"),
        ("offroad_scene_rate", "Off-road scene rate ↓", "rate"),
        ("scene_min_clearance_m_p05", "Scene clearance p05 [m] ↑", "float"),
        ("scene_min_clearance_noncollision_m_p05", "Non-collision scene clearance p05 [m] ↑", "float"),
        ("scene_ttc_s_p05", "Scene TTC p05 [s] ↑", "float"),
        ("terminal_clearance_m", "Terminal clearance [m] ↑", "float"),
        ("terminal_ttc_s", "Terminal TTC [s] ↑", "float"),
        ("critical_ttc_exposure_duration_s", "Critical-TTC exposure [s] ↓", "float"),
        ("near_zero_clearance_exposure_rate", "Near-zero-clearance exposure ↓", "rate"),
        ("closed_loop_bounded_NUP", "Bounded NUP ↑", "float"),
        ("intervention_rate", "Intervention rate", "rate"),
        ("decision_latency_ms", "Decision latency [ms] ↓", "float"),
    ],
    "contact": [
        ("num_scenes", "Scenes", "count"),
        ("counterfactual_contact_target_scene_rate", "Counterfactual-contact target rate", "rate"),
        ("observed_contact_scene_rate", "Observed-contact scene rate", "rate"),
        ("post_contact_metric_eligible_scene_rate", "Post-contact metric eligibility", "rate"),
        ("collision_scene_rate", "Collision scene rate ↓", "rate"),
        ("scene_min_clearance_m_p05", "Scene clearance p05 [m] ↑", "float"),
        ("scene_min_clearance_noncollision_m_p05", "Non-collision scene clearance p05 [m] ↑", "float"),
        ("terminal_clearance_m", "Terminal clearance [m] ↑", "float"),
        ("clearance_recovery_gain_m", "Clearance recovery gain [m] ↑", "float"),
        ("overlap_duration_s", "Overlap duration [s] ↓", "float"),
        ("penetration_scene_rate", "OBB penetration scene rate ↓", "rate"),
        ("penetration_duration_s", "OBB penetration duration [s] ↓", "float"),
        ("scene_max_penetration_depth_m_mean", "Mean scene max penetration [m] ↓", "float"),
        ("penetration_depth_auc_m_s", "Penetration-depth AUC [m·s] ↓", "float"),
        ("post_contact_terminal_clearance_m", "Observed-contact terminal clearance [m] ↑", "float"),
        ("post_contact_free_space_auc_normalized_m", "Observed-contact free-space AUC [m] ↑", "float"),
        ("post_contact_clearance_gain_m", "Observed-contact clearance gain [m] ↑", "float"),
        ("post_contact_escape_scene_rate", "Observed-contact escape rate ↑", "rate"),
        ("recontact_scene_rate", "Observed-contact re-contact rate ↓", "rate"),
        ("secondary_overlap_scene_rate", "Observed-contact secondary-overlap rate ↓", "rate"),
        ("new_stable_stop_quality_scene_rate", "Stable-stop-quality rate ↑", "rate"),
        ("offroad_scene_rate", "Off-road scene rate ↓", "rate"),
        ("post_contact_overlap_duration_s", "Observed-contact overlap [s] ↓", "float"),
        ("decision_latency_ms", "Decision latency [ms] ↓", "float"),
    ],
}


def _scene_journal(path: Path) -> Path | None:
    candidates = [Path(str(path) + ".scenes.jsonl"), path.with_suffix(path.suffix + ".scenes.jsonl")]
    return next((x for x in candidates if x.is_file()), None)


def _scene_keys(path: Path) -> set[str]:
    out: set[str] = set()
    with path.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            e = json.loads(line); s = e.get("scene", e)
            key = str(s.get("target_key") or e.get("resume_key") or "")
            if not key:
                scene_id = str(s.get("scene_id") or ""); t = s.get("target_time_index")
                key = f"{scene_id}:t{t}" if scene_id and t is not None else scene_id
            if key:
                out.add(key)
    return out


def _finite(x: Any) -> float | int | None:
    try:
        v = float(x)
        if not math.isfinite(v):
            return None
        return int(v) if v.is_integer() else v
    except Exception:
        return None


def _get(doc: dict[str, Any], key: str) -> float | int | None:
    if key == "decision_latency_ms":
        timing = doc.get("timing", {}) or {}
        per = timing.get("per_decision_s", {}) or {}
        # Publication latency is observation -> deployable action selection.
        # Never include teacher/audit labels or simulator/metric bookkeeping.
        if "deployed_planner" in per:
            return _finite(1000.0 * float(per["deployed_planner"]))
        deployed = ["state_history", "candidate_features", "policy_selection"]
        values = [float(per[k]) for k in deployed if k in per and per[k] is not None and math.isfinite(float(per[k]))]
        if values:
            return _finite(1000.0 * sum(values))
        # Very old artifacts exposed only a single total and cannot be safely
        # decomposed; retain compatibility as a last-resort fallback.
        if "total" in per:
            return _finite(1000.0 * float(per["total"]))
        return None
    if key in doc:
        return _finite(doc.get(key))
    wm = doc.get("waymax_metrics", {}) or {}
    return _finite(wm.get(key))


def _format(value: Any, kind: str) -> str:
    if value is None:
        return "—"
    v = float(value)
    if kind == "count":
        return str(int(round(v)))
    if kind == "rate":
        return f"{v:.4f}"
    return f"{v:.4f}"


def main() -> int:
    ap = argparse.ArgumentParser(description="Build regime-specific OC-RAP/external-baseline comparison tables.")
    ap.add_argument("--regime", choices=tuple(SCHEMA), required=True)
    ap.add_argument("--input", action="append", required=True, metavar="METHOD=RESULT.json")
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--allow-unpaired", action="store_true", help="Do not fail when scene journals exist but target sets differ.")
    args = ap.parse_args()

    entries: list[tuple[str, Path, dict[str, Any]]] = []
    for spec in args.input:
        if "=" not in spec:
            raise SystemExit(f"invalid --input {spec!r}; expected METHOD=PATH")
        method, raw = spec.split("=", 1); path = Path(raw)
        if not path.is_file():
            raise SystemExit(f"missing result: {path}")
        entries.append((method.strip(), path, json.loads(path.read_text(encoding="utf-8"))))

    journals = [(m, _scene_journal(p)) for m, p, _ in entries]
    present = [(m, j) for m, j in journals if j is not None]
    missing_journals = [m for m, j in journals if j is None]
    if missing_journals and not args.allow_unpaired:
        raise SystemExit(
            "missing scene journals required for paired comparison: "
            + ", ".join(missing_journals)
        )
    paired = False
    paired_count = None
    if len(present) == len(entries) and present:
        key_sets = {m: _scene_keys(j) for m, j in present if j is not None}
        reference_method = entries[0][0]; reference = key_sets[reference_method]
        mismatch = {m: {"only_reference": sorted(reference - ks)[:10], "only_method": sorted(ks - reference)[:10]} for m, ks in key_sets.items() if ks != reference}
        if mismatch and not args.allow_unpaired:
            raise SystemExit(f"unpaired closed-loop target sets: {json.dumps(mismatch, ensure_ascii=False)}")
        paired = not mismatch
        paired_count = len(reference) if paired else None

    rows: list[dict[str, Any]] = []
    for method, path, doc in entries:
        prov = find_provenance(method)
        row: dict[str, Any] = {
            "method": method,
            "reporting_name": prov.reporting_name if prov else method,
            "implementation_kind": prov.implementation_kind if prov else ("OC-RAP" if method.lower().startswith("ocrap") else "unknown"),
            "fidelity": prov.fidelity if prov else ("proposed method" if method.lower().startswith("ocrap") else "unknown"),
            "source_result": str(path),
        }
        for key, _, _ in SCHEMA[args.regime]:
            row[key] = _get(doc, key)
        rows.append(row)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.regime}_comparison"
    contact_eligibility = {
        method: _get(doc, "post_contact_metric_eligible_scene_rate")
        for method, _, doc in entries
    } if args.regime == "contact" else None
    contact_post_metrics_fully_paired = (
        bool(contact_eligibility)
        and all(v is not None and abs(float(v) - 1.0) <= 1.0e-12 for v in contact_eligibility.values())
    ) if args.regime == "contact" else None
    json_doc = {
        "schema_version": 2, "regime": args.regime, "paired_scene_set": paired,
        "paired_scene_count": paired_count,
        "metric_protocol": (
            "counterfactual-contact target cohort; generic physical metrics use all paired scenes, while post_contact_* metrics are strictly anchored only on observed Waymax overlap" if args.regime == "contact"
            else "deployable physical closed-loop metrics; expensive selected/all-candidate teacher certificate audits are excluded from the main table" if args.regime == "near"
            else "deployable physical closed-loop metrics"
        ),
        "contact_protocol": (
            "test_contact is a counterfactual contact-surrogate cohort in the current dataset build; raw WOMD replay does not materialize the contact impulse. "
            "Therefore post_contact_* values are conditional diagnostics only when an actual simulator overlap is observed and must not be described as a fully paired post-impact benchmark unless eligibility is 1.0 for every method."
            if args.regime == "contact" else None
        ),
        "contact_post_metrics_fully_paired": contact_post_metrics_fully_paired,
        "post_contact_metric_eligibility_by_method": contact_eligibility,
        "metrics": [{"key": k, "label": label, "kind": kind} for k, label, kind in SCHEMA[args.regime]],
        "rows": rows,
    }
    (args.output_dir / f"{stem}.json").write_text(json.dumps(json_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    fields = ["method", "reporting_name", "implementation_kind", "fidelity"] + [x[0] for x in SCHEMA[args.regime]]
    with (args.output_dir / f"{stem}.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows([{k: r.get(k) for k in fields} for r in rows])

    headers = ["Method"] + [x[1] for x in SCHEMA[args.regime]]
    lines = ["# " + args.regime.capitalize() + " regime comparison", "", f"Paired target set: **{paired}**" + (f" ({paired_count} scenes)" if paired_count is not None else ""), ""]
    if args.regime == "contact":
        lines += [
            "> Current `test_contact` is a counterfactual contact-surrogate cohort. Generic physical columns use the paired cohort; `post_contact_*` columns are strict observed-overlap diagnostics and are not a fully paired post-impact comparison unless observed-contact eligibility is 100% for every method.",
            "",
        ]
    elif args.regime == "near":
        lines += ["> The main Near table uses deployable physical closed-loop metrics. Exact teacher-label FRA/DRS/ODG audits are optional diagnostics and are not mixed into the runtime comparison.", ""]
    lines += ["| " + " | ".join(headers) + " |", "|" + "---|" * len(headers)]
    for r in rows:
        cells = [str(r["reporting_name"])] + [_format(r.get(k), kind) for k, _, kind in SCHEMA[args.regime]]
        lines.append("| " + " | ".join(cells) + " |")
    (args.output_dir / f"{stem}.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"event": "regime_comparison_table", "regime": args.regime, "methods": len(rows), "paired": paired, "output_dir": str(args.output_dir)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
